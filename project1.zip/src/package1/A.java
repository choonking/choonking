package package1;

public class A { //default (암것도 없으면 디폴트)
	public int field1;
	int field2; //같은 패키지 안에서만 접근 가능
	private int field3; //클래스A 내부에서만 
	
	public A() {
		field1 = 1;
		field2 = 1;
		field3 = 1;
		method1();
		method2();
		method3();
		}

//	public void method1() { //다 쓸수 있음 
//		// TODO Auto-generated method stub
//		
//	}
//
//	private void method3() { //클래스 A내에서만 
//		// TODO Auto-generated method stub
//		
//	}
//
//	void method2() { //같은 패키지만
//		// TODO Auto-generated method stub
//		
//	}
	

//	A a1 = new A (true);
//	A a2 = new A (1);
//	A a3 = new A ("string");
//	
//	public A(boolean b) {
//		
//	}
//
//	A(int b) { //같은 패키지에서만 접근 가능
//
//}
//
//
	private A(String string) { //class A에서만 접근이 가능 
	
	}

}
