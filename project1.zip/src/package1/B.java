package package1;
//A,B는 같은 패키지 내에있음
//A와 B 서로 접근 가능 

public class B {
//	A a; 
//	A a1 = new A(true);
//	A a2 = new A(1); // 같은 패키지라서 접근 가능
//	A a3 = new A("String");
	public void method() {
		A a = new A();
		a.field1 = 1;
		a.field2 = 1;
		a.field3 = 1; //private
		a.method1();
		a.method2();
		a.method3(); //private
	}

}
