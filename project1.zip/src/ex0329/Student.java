package ex0329;

public class Student {
	//컴파일러는 
	//개발자가 생성자를 정의하지 않은 경우 
	//기본 생성자(default constructor)를 만들어서 실행 
	//기본 생성자 -> 매개변수가 없는 생성자
	
	public Student(){
		
	}
}
