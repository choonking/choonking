package ex0329;

public class MemberExample {

	public static void main(String[] args) {
		
		Member user1 = new Member("홍길동", "hong");	
		
		System.out.println("이름: " + user1.name);
		System.out.println("아이디: " + user1.id);
		System.out.println("패스워드: " + user1.password);
		System.out.println("나이: " + user1.age);
		
		
		

		
		
			}

}
