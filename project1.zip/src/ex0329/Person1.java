package ex0329;

import java.util.Scanner;

class Person2 {
	String name;
	int age;
}








public class Person1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		 Person2 a1 = new Person2();  //Person2 class 참조
		 Person2 a2 = new Person2(); 
		 
		 System.out.print("친한 친구의 이름과 나이를 입력하세요. ");
		 a1.name = "손예준";	//내 이름
		 a1.age = 12;		//내 나이
		 a2.name = scan.next();		//친구 이름
		 a2.age = scan.nextInt();	//친구 나이
		 
		 System.out.printf("당신의 이름 : %s, 나이 : %d\n", a1.name, a1.age);
		 
		 System.out.printf("친구의 이름 : %s, 나이 : %d", a2.name, a2.age);
	}

}
