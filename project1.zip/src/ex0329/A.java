package ex0329;

public class A { //****클래스 앞에 public이 있으면
				 //파일 이름이 반드시 클래스 이름과 같아야함
				 //하나의 파일에 클래스를 여럿 정의하는 경우
				 //딱 하나의 클래스에만 public 허용
}

class B{
	
}
class C{
	class D{
		
	}

}
