package ex0329;

public class arrayEx4 {

	public static void main(String[] args) {	//args에 데이터 입력 되있음 
		
		double sum = 0.0;						//double = 소수점 때매 필요함  
		
//for(int i=0; i<args

		for(String k : args) {					//밑의 수식을 반복
		 
			sum+=Double.parseDouble(k);			//str타입이기 때문에 double로 바꿔야 계산이됨
			
	}
		System.out.printf("합은 %.2f\n", sum);
		System.out.printf("평균은 %.2f", sum/args.length);
			
	

	}
	
}

