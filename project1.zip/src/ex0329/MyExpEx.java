package ex0329;

class MyExp	{
	int base;
	int exp;
	int getValue() {//base를 exp만큼 곱한 결과를 반환
		int result = 1;
		for(int i=1; i<=exp; i++)	{
			result = result*base; //result*=base;
		
			//base*base*base....*base
			//1*2*2*2 //base:2 exp:3
		}
		return result;
	
	}

}







public class MyExpEx {

	public static void main(String[] args) {
		//2의 3승
		//3의 4승
	
		MyExp e1 = new MyExp();
		e1.base=2; e1.exp=3;
		System.out.printf("%d 의 %d승 = %d\n" ,e1.base, e1.exp, e1.getValue());
		
		MyExp e2 = new MyExp();	
		e2.base=3; e2.exp=4;
		System.out.printf("%d 의 %d승 = %d" ,e2.base, e2.exp, e2.getValue());
		
	}

}
