package ex0329;

public class Hello { //public -> 공공의, 누구나 쓸수 있음 
				     //접근 제한자, 접근 지시자, 접근지정자 (modifier)

	public static void main(String[] args) {
		
	}

}
