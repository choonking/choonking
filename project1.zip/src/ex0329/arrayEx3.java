package ex0329;

public class arrayEx3 {

	public static void main(String[] args) {
		int [] num = {1,2,3,4,5,6,7,8,9,10};
		int sum = 0; //0+1+2+3+4+5
		for (int k : num) {
			 sum = sum+k;
		}
		System.out.printf("합은 %d \n", sum);
		
		
		String names[]= {"사과 ", "배 ","바나나 ","체리 ", "딸기 ","포도"};
		for (String s : names)
			System.out.print(s+"");
	
		}
	}

