package ex0329;

public class Car {
	//필드 선언
	String company = "현대 자동차";
	String model ="그랜저";
	String color;
	int maxSpeed = 350;
	int speed;
	//필드만 있음
	Car(){
		color="white";
	}
	public void speedUp() {
		speed += 40;
	}
	
}
