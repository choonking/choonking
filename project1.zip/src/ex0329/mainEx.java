package ex0329;

import java.util.Scanner;

public class mainEx {

	public static void main(String[] args) {
//		System.out.println(args.length);
//		double [] brgs = new double [args.length];
//		int[] irgs = new int[4];
		Scanner scan = new Scanner(System.in);
		System.out.print("학생수를 입력하세요");
		int num=scan.nextInt();
		String[] strArray1 = new String[num];
		for(int i=0; i<strArray1.length; i++) {
		System.out.print("학생의 점수를 입력하세요");
		strArray1[i] = scan.next();
		}
		double sum = 0.0;
		
		for(int i=0; i<strArray1.length; i++) {
			sum = sum + Double.parseDouble (strArray1[i]);
			System.out.printf("%s\n",strArray1[i]);
		}
//			
//			for(int i=0; i<brgs.length; i++) {
//				brgs[i] = Double.parseDouble(args[i]);
//			}
//			
//			for(int i=0; i<irgs.length; i++)	{
//				
//				
//			
//		}
			
			
			System.out.printf("입력 받은 인자들의 평균 : %.2f", sum/strArray1.length);
	}
}

