package ex0329;

class Person {
	//필드

	public String name;
	public int age;
	//메소드
	public String getName() {
		return name;
	}
	//생성자 ->  constructor
	//필드들을 초기화
	//new와 함께 객체를 생성할 때 호출됨
	public Person() { 
		

	}
	public Person(String n) { //매개변수 생성자
		name = n;
	}

}	//Person class
public class PersonEx {
	
	public static void main(String[]args)	{
		//new 생성자 호출
		Person aPerson= new Person(); //Person 객체 생성
		
		System.out.println(aPerson.age);
		System.out.println(aPerson.name);
		System.out.println(aPerson.getName()); //null
		
		Person bPerson = new Person("코로나");
		
		System.out.println(bPerson.age);
		System.out.println(bPerson.name);
		System.out.println(bPerson.getName()); //코로나
		bPerson.age=10;	
		System.out.println(bPerson.age);
	
		
	}
}