package ex0329;

public class Korean {
	//필드 선언
	String nation = "ROK";
	String name;
	String ssn;
	
	//생성자 선언
	public Korean(String n, String s) {
		name = n;
		ssn = s;
	}
}
