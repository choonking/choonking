package ex0329;

public class mainEx3 {

	public static void main(String[] args) {
		String[] strArray = new String[4];
		for(int i=0; i<strArray.length; i++) {
//			System.out.println(strArray);
		}
		strArray[0]="Hello";
	    strArray[1]="Java";
	    
	    
	    for(int i=0; i<strArray.length; i++) {
	    	System.out.println(strArray[i]);
	    }
	}

}
