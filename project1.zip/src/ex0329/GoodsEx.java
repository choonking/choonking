package ex0329;

class Goods {
	String name;
	int price;
	int numberOfStock;
	int sold;
}


public class GoodsEx {

	public static void main(String[] args) {
		Goods shampoo = new Goods();
		shampoo.name="앨라스틴";
		shampoo.price=13000;
		shampoo.numberOfStock =30;
		shampoo.sold = 50;
		
		System.out.println("상품 이름: " +shampoo.name);
		System.out.println("상품 가격: " +shampoo.price+"원");
		System.out.println("재고 수량: " +shampoo.numberOfStock+"개");
		System.out.println("팔린 수량: " +shampoo.sold+"개");

	}

}
