package ex0329;

import java.util.Scanner;

class Student2	{
	String schoolName;
	int year;
}









public class Student1 {

	public static void main(String[] args) {
//		"학교명", "학년"을 저장할 수 있는 구조체로 2개의 변수를 선언한 후,
//		한 개의 변수는 학교명에 "Jejuelementary", 학년에 "6"으로 각각 초기화하고 
//		다른 변수에는 새로운 학교와 학년을 입력받아 아래와 같이 출력하는 프로그램을 작성하시오.
//		학교명은 20자 이하의 영문자이다.
//		6 grade in Jejuelementary School //초기화한 것
//		1 grade in Seogwipomiddle School //입력받은 것
		
		Scanner scan = new Scanner(System.in);
		Student2 a1 = new Student2();
		Student2 a2 = new Student2();
		
		a1.schoolName = "Jejuelementary School";
		a1.year = 6;
		a2.schoolName = scan.next();
		a2.year = scan.nextInt(); 
		System.out.printf("%d grade in %s\n", a1.year,a1.schoolName);
		System.out.printf("%d grade in %s\n", a2.year,a2.schoolName+" School");
	}

}
