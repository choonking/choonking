package ex0329;

public class mainEX2 {

	public static void main(String[] args) {
		double sum = 0.0;
		
		for (int i=0; i<args.length; i++) {
			sum+=Double.parseDouble(args[i]);
		}
		System.out.printf("평균은 %.2f", sum/args.length);
	}

}
