package Ex0328;

import java.util.Scanner;

public class PracArray8 {

	public static void main(String[] args) {
		//	정수형으로 된 두 개의 문자열을 입력받아 합계를 출력하고 실수형으로
		//	된 두 개의 문자열을 입력받아 합계를 출력하는 프로그램을 작성하시오. 
		//	(입력되는 문자열의 길이는 10자 이하이며 실수는 반올림하여 소수 둘째자리까지 출력한다.)
		
		//입123 4567	
		// 123.253 5236.12
		//출 123 + 4567 = 4690
		//  123.25 + 5236.12 = 5359.37
		
		
		String []	strArray= new String[4];
		Scanner scan = new Scanner(System.in);
		for(int i=0; i<strArray.length; i++)	{
			strArray[i] = scan.next();
	
		}
		
		int n1 = Integer.parseInt(strArray[0]);
		int n2 = Integer.parseInt(strArray[1]);
		System.out.printf("%d + %d = %d\n", n1,n2,n1+n2); 
		
		double n3 = Double.parseDouble(strArray[2]);
		double n4 = Double.parseDouble(strArray[3]);
		System.out.printf("%.2f + %.2f = %.2f",n3,n4, n3+n4);


	}

}
