package Ex0328;

import java.util.Scanner;

public class PracArray4 {

	public static void main(String[] args) {
//1반부터 6반까지의 평균점수를 저장한 후 두 반의 반 번호를 입력받아 두 반 평균점수의 합을 출력하는 프로그램을 작성하시오.
//반별 평균점수는 초기값으로 1반부터 차례로 85.6 79.5 83.1 80.0 78.2 75.0으로 초기화하고 
//출력은 소수 두 번째 자리에서 반올림하여 소수 첫째자리까지 한다.
		
		
//입		1 3
//출 	168.7	
		
		Scanner scan= new Scanner(System.in);
		double nums [] = new double [6];
		nums[0]= 85.6;
		nums[1]= 79.5;
		nums[2]= 83.1;
		nums[3]= 80.0;
		nums[4]= 78.2;
		nums[5]= 75.0;
	
		for(int i=0; i<nums.length;)	{
			for(int j=0; j<nums.length;)	{
				nums[i]=scan.nextDouble();
				nums[j]=scan.nextDouble();
			
				
			}
			double avg = (nums[i]+nums[j]/2);
			System.out.print((double)avg);
		}
			
	}
}
