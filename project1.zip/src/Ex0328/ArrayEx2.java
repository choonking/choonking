package Ex0328;

import java.util.Scanner;

public class ArrayEx2 {

	public static void main(String[] args) {

//		String strArray[] = new String[2];
//		for(int i=0; i<strArray.length; i++) { //null 로 초기화 ->참조하고 있지 않음
//			System.out.println(strArray[i]);
//		}
//
//		Scanner scan= new Scanner(System.in);
//
//		strArray[0]="Hello";
//		strArray[1]=new String("Java");
//		//i love Java
//		strArray[0]=scan.next(); //한단어만 읽어옴
//		strArray[0]=scan.nextLine();//한줄만 읽어옴 ->\n까지 포함해서 읽어옴
		String str = "i love korea."; //공백은 구분자 "i","love","Korea."
		String[] strArray = str.split(" ");
		
		for (int i=0; i<strArray.length; i++)	{
			System.out.println(strArray[i]);
		}
	}

}
