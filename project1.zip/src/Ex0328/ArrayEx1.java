package Ex0328;

import java.util.Scanner;

public class ArrayEx1 {

	public static void main(String[] args) {
		
//		int score1; 
//		score1 = 100;
//		System.out.println(score1);
//		score1 = 99;
//		System.out.println(score1);
			
//		int [] scores; //int형 데이터를 저장할 수 있는 배열 객체를 참조하는 
					   //레퍼런스 scores 선언					   //stack에 scores라고 하는 레퍼런스 생성
//		int grades []; //객체 없이 레퍼런스만 추가된 상태
		//오른쪽은 90,70,50 정수타입의 값을 연속된 공간에 저장하는 배열 객체 생성
//		int [] scores = {90, 70, 50, 32, 46, 78, 87, 100,88,99} ;
				
		
//		int sum=0;
//		sum+=scores[0]; //0+90
//		sum+=scores[1]; //0+90+70
//		sum+=scores[2]; //0+90+70+50
//		System.out.println("총점 : "+sum);
		
//		sum=0;
//		for(int i=0; i<scores.length; i++) {
//			sum+=scores[i];
//			System.out.println(scores[i]);
//		}
//		System.out.printf("총점 : %d\n", (sum));
//		System.out.printf("평균 : %d", (sum/scores.length));
		
//		double []nums = {90.5, 88.5, 33.4};
//		String[]strs = {"가", "나", "다"};
//		char chs []= {'a', 'b', 'c'};
//		boolean bs[]= {true, false}; //bs[0], bs[1]
//		for (int i=0; i<bs.length; i++) { //bs에 있는 갯수만큼 
//			System.out.println(bs[i]);
			
//		System.out.println(scores[0]);
//		System.out.println(scores[1]);
//		System.out.println(scores[2]);
//		System.out.println(scores[3]);
//		System.out.println(scores[4]);
//		System.out.println(scores[5]);

		Scanner scan = new Scanner(System.in);	
		int grades [] = new int [3];
//		System.out.println("배열 생성 직후 확인");
//		for(int i=0; i<grades.length; i++)	{
//			System.out.println(grades[i]);
//		}
//		grades[0]=10;
//		grades[1]=20;
//		grades[2]=30;
		for(int i=0; i<grades.length; i++)	{
			System.out.println("학생의 점수를 입력하세요 >>");
			grades[i] = scan.nextInt(); //키보드로 입력받는 형태로 변경
	}
		
			System.out.println("-------------------------");
			System.out.println("새로운 값을 저장 후 확인"); //10 20 30
			//총점:0+grades[0]+grades[1]+grades[2]
			int sum= 0;
			sum=0;
//			sum= sum+grades[0];
//			sum= sum+grades[1];
//			sum= sum+grades[2];		
			for(int i=0; i<grades.length; i++) {
				sum = sum+grades[i];
			//	System.out.println(grades[i]);
			
		}
			System.out.println("학생의 총점은 " +sum);
			System.out.println("학생의 총점은 " +(sum/(double)grades.length));
	}
}




