package Ex0328;

import java.util.Scanner;

public class PracArray7 {

	public static void main(String[] args) {
		//길이가 49 이하인 두 개의 문자열을 입력받아서
		//길이가 짧은 문자열을 먼저 출력하고 다음 줄에 나머지
		//문자열을 출력하는 프로그램을 작성하시오.
		//(길이가 같은 경우에는 순서대로 출력한다.) 
//입 information Jungol
//출 information
//	Jungol
		Scanner scan = new Scanner(System.in);
//		String str1 = scan.nextLine();
//		String str2 = scan.nextLine();
//		int long1=str1.length();
//		int long2=str2.length();
//		
//		if(long1>=long2) {
//			System.out.println(str1);
//			System.out.print(str2);
//			
//		}
//		else	{
//			System.out.println(str2);
//			System.out.print(str1);
		String [] stArray = new String[2];
		for(int i=0; i<stArray.length; i++)	{
			stArray[i] = scan.next();
		}	
		for(int i=0; i<stArray.length; i++)	{
//		System.out.println(stArray[i].length());
		}
		if(stArray[0].length()<=stArray[1].length()){
			System.out.println(stArray[0]);
			System.out.println(stArray[1]);
			
		}
		else {
			for(int i=stArray.length-1; i>=0; i--)	{ //1,0순
				System.out.println(stArray[i]);	}
		}
	}
}


