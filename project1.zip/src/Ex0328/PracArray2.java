package Ex0328;

import java.util.Scanner;

public class PracArray2 {

	public static void main(String[] args) {
//	//문자 10개를 저장할 수 있는 배열을 만들고 
//	//10개의 문자를 입력받아 입력받은 문자를 이어서 출력하는 프로그램을 작성하시오.
//	//	A B C D E F G H I J
//	Scanner scan= new Scanner(System.in);
//	char [] chArray = new char[10];
//	chArray[0] = scan.next().charAt(0); //-> "A"->'A'
//	
//	chArray[9] = scan.next().charAt(0); //-> "J"->'J'
//	for(int i=0; i<chArray.length; i++)	{
//		chArray[i]=scan.next().charAt(0);
//		}
//	for(int i=0; i<chArray.length; i++) {
//	System.out.print(chArray[i]);
//	}
	
//정수 10 개를 저장할 수 있는 배열을 만들어서 1 부터 10 까지를 대입하고 차례대로 출력하는 프로그램을 작성하시오.
//입 1 2 3 4 5 6 7 8 9 10
	
	int nums [] = new int [10];
//	nums[0] = 1;
//	nums[1] = 2;
//	nums[2] = 3;
//	nums[3] = 4;
//	
	
	for(int i=0; i<nums.length; i++) {  //값을 대입
		nums[i]=i+1;
		
	
	}
	for(int i=0; i<nums.length; i++) {  //값을 출력 
		System.out.print(nums[i]+" ");
	}
	
	
	
	}

}
