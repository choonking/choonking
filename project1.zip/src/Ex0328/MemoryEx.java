package Ex0328;

import java.util.Scanner;

public class MemoryEx {

	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		int num = scan.nextInt();
		
		//H[0] e[1] l[2] l[3] o[4]  <==위치는 index
//		String str ="Hello";
		 
		//역순으로 출력
		
//		System.out.print(str.charAt(4));
//		System.out.print(str.charAt(3));
//		System.out.print(str.charAt(2));
//		System.out.print(str.charAt(1));
//		System.out.print(str.charAt(0)); //마지막 인덱스는 length -1
		
		
//		System.out.println("-------------");
										//str.length()-1 --> 4
			
//		for(int i=str.length()-1; i>=0; i--) {
	//		System.out.print(str.charAt(i));
		
		String a = new String(" abcd");	String b = new String(",efg");
		a= a.concat(b); System.out.println(a);
		// 콘캣: 걍 합쳐버림
		a= a.trim();	System.out.println(a);
		// 트림:앞,뒤 공간 공백 제거
		a= a.replace("ab", "12");	System.out.println(a);
		// 리플레이스 : 문자열을  대체함
		a=a.substring(3);	System.out.println(a);
		//서브 스트링 : 지정된 인덱스 부터 출력함
		char c=a.charAt(2);	System.out.println(c);
			

		 
		}
		 
		 
}


