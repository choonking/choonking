package Ex0328;

import java.util.Scanner;

public class PracArray {

	public static void main(String[] args) {
		//5개의 정수를 입력받은 후 차례로 출력하는 프로그램을 작성하시오.
		//입 5 10 9 3 2 
		//출 5 10 9 3 2
		
		Scanner scan = new Scanner(System.in);
		int nums [] = new int [5];
			
		for(int i=0; i<nums.length; i++) {
			nums[i]=scan.nextInt();	
			}
		for(int i=0; i<nums.length; i++) {
			System.out.print(nums[i]+" ");	
			}

	}
}


