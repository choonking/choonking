package Ex0328;

import java.util.Scanner;

public class StrArray {

	public static void main(String[] args) {
		
//		String strArray[]= {"1", "2", "3", "4"};
//		int sum=0;
//		for(int i=0; i<strArray.length; i++)	{
//			sum= sum+Integer.parseInt(strArray[i]);
//			//System.out.println(strArray[i]);
//		}
//		System.out.println("sum : "+sum);
//		//0+"1" -> "0"+"1" ->"01"	
//		String s1 = "1";
//		String s2 = "2";
//	System.out.println(s1+s2);		
//		int n1 = Integer.parseInt(s1); //1
//		int n2 = Integer.parseInt(s2); //2 
//		System.out.println(n1+n2); 	   //3	
//		String s3 = "1";
//		String s4 = "2.0";
//		//System.out.println(s3+s4); 		
//		double n3 = Double.parseDouble(s3); //1.0 double형으로해서 1인데 1.0이됨 
//		double n4 = Double.parseDouble(s4); //2.0
//		//System.out.println(n3+n4);		//3.0
		
		String [] strArray=new String[4];
		//키보드에서 문자열을 입력하세요 입 "1","2","3","4"를 순차적으로 
		//배열 strArray에 참조시킬 예정
		Scanner scan = new Scanner(System.in);
		for(int i=0; i<strArray.length; i++)	{
			strArray[i] = scan.next();
		}
		int sum=0; // 
		for(int i=0; i<strArray.length; i++)	{
			sum = sum+ Integer.parseInt(strArray[i]); //문자열이기 때문에 int형으로 바꿔서 저장 
			System.out.println(strArray[i]);
		}
		System.out.println("sum : "+sum);
		System.out.printf("average :%.2f",sum/(double)strArray.length);
		
	}

}
