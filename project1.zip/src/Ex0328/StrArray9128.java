package Ex0328;

import java.util.Scanner;

public class StrArray9128 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String[] strArray1 = new String[2];
		
		String[] strArray2 = new String[2];
		int[] iArray1 = new int[2];
		double [] dArray2 = new double[2];
		for(int i=0; i<strArray1.length; i++) {
			strArray1[i] = scan.next();
		}
		for(int i=0; i<iArray1.length; i++) {
			iArray1[i] = Integer.parseInt(strArray1[i]);
		}

		for(int i=0; i<strArray2.length; i++) {
			strArray2[i] = scan.next();
		}
		
		for(int i=0; i<dArray2.length; i++) {
			dArray2[i] = Double.parseDouble(strArray2[i]);
		}
		int sum1=0;
		for(int i=0; i<iArray1.length; i++)	{
			sum1 = sum1+iArray1[i];
		}
		
		double sum2 = 0.0;
		for(int i=0; i<dArray2.length; i++)	{
			sum2 = sum2+(dArray2[i]);
		}
		
		System.out.printf("%d + %d = %d\n", iArray1[0],iArray1[1], sum1);
		System.out.printf("%.2f + %.2f = %.2f",dArray2[0],dArray2[1], sum2);
		
	}

}
