package Ex0328;

import java.util.Scanner;

public class PracArray5 {

	public static void main(String[] args) {
		// 9118 5개의 단어를 입력받아 배열에 저장한 후 출력하는 프로그램을 작성하시오. 각 단어의 길이는 20자 미만이다. 
		
		//입 jungol 				
		//  information
		//  gifted
		//  center
		//  higc
		//출 jungol
		//  information
		//  gifted
		//  center
		//  higc
		Scanner scan = new Scanner(System.in);//<--입력받기위한 스캐너 <-1
		String[] strArray = new String[5]; //<= 현재 null로 저장되어짐   배열생성 <-2
		
		for(int i=0; i<strArray.length; i++)	{ // 반복해서 입력받음 <-3
			strArray[i]=scan.next();
		}
		for(int i=0; i<strArray.length; i++)	{ // i반복해서 출력함 <-4
			System.out.println(strArray[i]);

		}
		for(int i=strArray.length-1; i>=0; i--)	{ // 역순으로 출력함 <-bonus 
			System.out.println(strArray[i]);

		}
		
		
		
		
		
		
		
		
	}

}
