package Ex0328;

import java.util.Scanner;

public class PracArray6 {

	public static void main(String[] args) {
//		// 5개의 단어를 입력받아 모든 단어를 입력받은 역순으로 출력하는 프로그램을 작성하시오.
//		// 각 단어의 길이는 30이하이다.
//		Scanner scan = new Scanner(System.in);
//		String [] strArray = new String[5];
//		
//		for(int i=0; i<strArray.length; i++)	{ // 반복해서 입력받음 <-3
//			strArray[i]=scan.next();
//		}
//		for(int i=strArray.length-1; i>=0; i--) {
//			System.out.println(strArray[i]);
//		}
//49자 이하의 한 문장을 입력받아서 단어 단위로 구분하여 문자열을 배열에 저장하고 출력하는 프로그램을 작성하시오. 
//입		I like you better than him.	
//출		I
//		like
//		you
//		better
//		than
//		him
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		String strArray[]= str.split(" "); //1개 자리 
		
		for (int i=0; i<strArray.length; i++)	{
			System.out.println(strArray[i]);
		
		}	
	}

}
