package Ex0328;

import java.util.Scanner;

public class PracArray3 {

	public static void main(String[] args) {
//	정수 10개를 입력받은 후 세 번째, 다섯 번째와 마지막으로 입력받은 정수를
//	차례로 출력하는 프로그램을 작성하시오.
		
//	입	5 3 9 6 8 4 2 8 10 1
// 	출 	9 8 1
		
		Scanner scan= new Scanner(System.in);
		int [] nums = new int[10];
		
		for(int i=0; i<nums.length; i++) { //값을 입력받음 
			nums[i]=scan.nextInt();	
		}
		System.out.print(nums[2]+" ");
		System.out.print(nums[4]+" ");	
		System.out.print(nums[9]);
	}
		
	
}
