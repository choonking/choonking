package Ex0328;

import java.util.Scanner;

public class pracArray9 {

	public static void main(String[] args) {
		//공백을 포함한 문자열을 입력받아 각 단어로 분리하여 문자열 배열에 저장한 
		//후 입력순서의 반대 순서로 출력하는 프로그램을 작성하시오.
		//문자열의 길이는 100자 이하이다.
		//입 C++ Programing jjang!!
		//출 jjang!!
		//	Programing
		//	C++
	
	Scanner scan = new Scanner(System.in);
	String str = scan.nextLine();
	String strArray[]= str.split(" "); 
	
	for (int i=strArray.length=1; i>=0; i--)	{
		System.out.println(strArray[i]);
		
	}
	
	
	
	
	}
	

}

