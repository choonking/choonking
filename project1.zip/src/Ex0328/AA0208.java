package Ex0328;

public class AA0208 {

	public static void main(String[] args) {
		
		System.out.print();
	}

}
