package com.ezen.www;

import java.util.Iterator;

public class VerEx {

			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	//int price; //정수형 변수 선언
		//double x, y, z; //실수형 변수 선언
		//변수 이름의 작명 규칙
		//영어 알파벳 혹은 한글로 정할 것
		//대소문자 구별함 x, X (서로 다름)
		//숫자를 포함해도 좋음, 단 숫자로 시작할 수 없음
		//특수기호는 불가 (단 _, $ 제외)
		
		/*
		 권장사항
		 한글 이름 x
		 가급적 소문자로 시작
		 만약에 영어단어 2개이상 짓게되면, 첫글자는 소문자로 두번째는 대문자로 시작
		 
		 */
		
		int score = 90;
		System.out.println(score);
		
		score = 70;							// score 값을 변경
		System.out.println(score);
		
		score = 50;
		System.out.println(score);
		
		double x = 3.14;
		System.out.println(x); 
		
		// '' = 작은 따옴표는 문자1개 예:) 'a', ' ', 'A', '1'
		
		char ch1 = 'a';
		char ch2 = 'A';
		char ch3 = ' ';
		
		// "" = 큰 따옴표는 문자열, 1개도 상관없음 예:) "abc" , "a"
		
		String str1 ="";
		String str2 = "dfadf";
		String str3 = "A";
		
		System.out.println(ch2);
		System.out.println(str3);
		
		
		int fifteen10 = 15;
		int fifteen16 = 0xF; 	// 0x로 시작하면 16진수
		
		System.out.println(fifteen10);
		System.out.println(fifteen16);
		
		long fifteen = 15L; 	// L or l 은 long형을 의미함
		System.out.println(fifteen);
		
		long speed = 3000000000L;
		
		double half = 0.5;
		System.out.println(half);
		half = 5E-1;			 // 5 * 10^-1
		System.out.println(half);
		
		
		float half1 = 0.5f; // F or f 은 float형을 의미함
		float half2 = 0.5F;
		
		System.out.println(half1);
		System.out.println(half2);
		
		float pi1 = 3.14159f;
		float pi2 = 3.14159F;
		double pi3 = 3.14159;
		
		System.out.println(pi1);
		System.out.println(pi2);
		System.out.println(pi3);
		
		
		boolean isEmpty = false;
		System.out.println(isEmpty);
	
		
	}

}
