package com.ezen.www;

import java.util.Scanner;

//import java.util.Scanner;

public class OpEx {

	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in);
//		
//		System.out.print("몸무게(kg) : ");
//		int weight = scan.nextInt();
//		System.out.print("신장(m) : ");
//		double height = scan.nextDouble();
//		
//		int bmi = (int)(weight/(height*height));
//		System.out.println("BMI : " + bmi );
		Scanner scan = new Scanner(System.in);
		
		System.out.print("빵의 갯수를 입력하세요 : ");
		int bread = scan.nextInt();
		
		System.out.print("1인당 몇개씩 분배할 것인지 입력하세요 : ");
		int div = scan.nextInt();
		
		System.out.println("빵을 나누어 줄 수 있는 학생의 수 : " + bread/div );
		System.out.println("남은 빵 개수 : " + bread%div );
		
		
	}

}
