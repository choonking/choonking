package com.ezen.www;

import java.util.Scanner;

public class TypeScanner {

	public static void main(String[] args) {
		
		
	  Scanner scan = new Scanner(System.in);
//	  int num = scan.nextInt(); // 키보드에서 숫자를 정수로 입력받음
//	  System.out.println(num);
//	  System.out.println(scan.nextInt());
//	  
//	  double num1 = scan.nextDouble();
//	  System.out.println(num1);
	  
//	  String str = scan.next(); //문자열을 읽어서 반환 "..."
//	  System.out.println(str+2);
	  
//	  System.out.println("이름, 주소, 나이, 키 순서대로 입력하세요 : ");
//	  String name = scan.next();
//	  String addr = scan.next();
//	  int age = scan.nextInt();
//	  double height = scan.nextDouble();
//	  System.out.println("이름은 " + name + ", 주소는 " + addr + ", 나이는 " + age + ", 키는 " + height + "입니다");
//	  
	  
	  System.out.print("당신의 이름을 입력하세요-->>");
	  String name = scan.next();
	  System.out.print("당신의 주소를 입력하세요-->>");
	  String addr = scan.next();
	  System.out.print("당신의 나이를 입력하세요-->>");
	  int age = scan.nextInt();
	  System.out.print("당신의 키(cm)를 입력하세요-->>");
	  double height = scan.nextDouble();
	  
	  System.out.println("이름 : " + name);
	  System.out.println("주소 : " + addr);
	  System.out.println("나이 : " + age);
	  System.out.println("키 : " + height);
	  
	  
	}

}
