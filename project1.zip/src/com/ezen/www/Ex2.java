package com.ezen.www;

public class Ex2 {

	public static void main(String[] args) {
		int opr = 0;
		opr += 3;
		
		System.out.println(opr++); // opr 출력 후 증가, 출력은 3, opr = 4
		System.out.println(opr);
		System.out.println(++opr); // opr 증가 후 출력, opr = 5, 출력은 5
		System.out.println(opr);
		System.out.println(opr--); // opr 출력 후 감소, opr = 4, 출력은 5
		System.out.println(opr); 
		System.out.println(--opr); // opr 감소 후 출력, opr = 3, 출력은 3
		System.out.println(opr);
		
		
	}

}
