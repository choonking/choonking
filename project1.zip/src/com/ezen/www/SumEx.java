package com.ezen.www;

public class SumEx {

	public static void main(String[] args) {
	    System.out.println(1);
	 
	}

}
