package com.ezen.www;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		double a = scan.nextDouble();
		double b = scan.nextDouble();
		
		if ((a >= 4.0) && (b >= 4.0)) { 	//a 와 b가 모두 4.0 이상 일때
			System.out.println("A");
		} else if ((a >= 3.0) && (b >= 3.0) ) { 	//a 와 b가 모두 3.0 이상 일때	
			System.out.println("B");
		} else { 	//나머지	
			System.out.println("C");
		}
	}
}

