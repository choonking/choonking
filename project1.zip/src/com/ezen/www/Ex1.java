package com.ezen.www;

public class Ex1 {

	public static void main(String[] args) {
		int num1, num2, num3;
		num1 = num2 = num3 = 100; //오른쪽부터 연산 처리
		//num3에 100을 저장
		//num3에 저장된 값, 100을 읽어와서 num2에 저장
		//num2에 저장된 값, 100을 읽어와서 num1에 저장
//		System.out.println("num1 : " + num1 );
//		System.out.println("num2 : " + num2 );
//		System.out.println("num3 : " + num3 );
		
		int a,b = 4; // a는 초기화되지 않음
//		a = b++ + 10;       // b에 저장된 4와 10을 더한 다음, b에 저장된 값을 1증가 a = 14, b = 5;
		
//		a = ++b + 10;   	// b에 저장된 4에 1을 증가한 다음 b ->5 , b의 값을 읽어와서 10과 더한 다음 a에 저장 a = 15, b = 5;
		
//		a = b-- + 10;       // b에 저장된 4와 10을 더한 다음, b에 저장된 값을 1감소 a = 14, b = 3;
		
		a = --b + 10;       // b에 저장된 4에 1을 감소한 다음 b -> 3 , b의 값을 읽어와서 10과 더한 다음 a에 저장 a = 13, b = 3;
		
		System.out.println("a : " + a);
		System.out.println("b : " + b);
	}

}
