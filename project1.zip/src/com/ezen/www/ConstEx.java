package com.ezen.www;

public class ConstEx {
	
	public static void main(String[] args) {
//		double d1 = 5 * 3.14; //*전에 5를 5.0으로 자동 형변환 (Promotion) 암시적 형변환
//		System.out.println(d1);
//		double d2 = 1;			//1을 1.0으로 자동 형변환
//		System.out.println(d2);
//		
//		//------------------------------------------
//		float f = (float)3.14; //강제 타입변환, 명시적 형변환
//		byte b = (byte)300;
//		System.out.println(b);
//		
//		System.out.println("5*3.14= " + d1);
//		System.out.println("a" + "b");
//		System.out.println("결과는 : " + d1);
//		System.out.println("참이냐 거짓이냐 " + true);
//		
//		int r = 1;
//		double pi = 3.14;
//		double cir = 2*pi*r;
//		double area = pi*r*r;
//		System.out.println("반지름이 " + r + "인 원의 둘레는 " + cir + " 면적은 " + area + "입니다");
//		System.out.printf("반지름이 %d인 원의 둘레는 %f 면적은 %f입니다\n", r, cir, area);
//		System.out.printf("반지름이 %03d인 원의 둘레는 %4.2f 면적은 %5.2f입니다\n", r, cir, area);
//		
//		double x = 123.45;
//		System.out.printf("%f\n",x);
//		System.out.printf("%7.1f\n",x);
//		System.out.printf("%7.3f\n",x);
//		
//		
//		String str = "Hi~Java";
//		System.out.printf("%s\n",str);
//		System.out.printf("%10s\n",str);
		
		int i = 97;
		System.out.printf("%d\n", i);
		System.out.printf("%x\n", i);
		System.out.printf("%c\n", i);
		System.out.printf("%5d\n", i);
		System.out.printf("%05d\n", i);
		
		String s = "Java";
		System.out.printf("%s\n",s);
		System.out.printf("%5s\n",s);
		System.out.printf("%-5s\n",s);
		
		double f = 3.14f;
		System.out.printf("%f\n",f);
		System.out.printf("%e\n",f);
		System.out.printf("%4.1f\n",f);
		System.out.printf("%-4.1f\n",f);
		
	}

}
