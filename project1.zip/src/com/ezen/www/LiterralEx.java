package com.ezen.www;

public class LiterralEx {

	public static void main(String[] args) {
		char c1 = 'A';
		char c2 = 65;
		char c3 = '\u0041';
		String c4 = "A"; 				// String 은 반드시 대문자로 시작
		
//		System.out.println(c1);
//		System.out.println(c2);
//		System.out.println(c3);
//		System.out.println(c4);
//		System.out.println('\t');
		System.out.println("aaabbb");
		System.out.println("aaa\tbbb");  //탭
		System.out.println("aaa\nbbb");  //줄 바꿈
		System.out.println("\"aaa\"");   //큰 따음표
		System.out.println("\'aaa\'");   //작은 따음표
		// null은 참조형에면 쓸 수 있음 예:) String (int,double 불가)
		String str = null; // null 의미는 정하지 않았다는 뜻
		
		// 상수(final) (절대 바뀌지 않는 값)
			final double PI = 3.141592; //변하지 않는 값을 저장하기 위한 변수
			System.out.println(2*2*PI);
			
			
	}

}
