package com.ezen.www;

import java.util.Scanner;

public class BooleanEx {

	public static void main(String[] args) {
		
//		System.out.println(3 < 5);    	//true
//		System.out.println(3 > 5);		//false
//		System.out.println(1 <= 0);		//false
//		System.out.println(10 >= 10);	//true
//		System.out.println(1 == 3);		//false
//		System.out.println(1 != 3);		//true
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("어린이의 신장(cm)을 입력하세요 : ");
		int height = scan.nextInt();
		System.out.println( (height >= 125) && (height < 165) );
		
		
	}

}
