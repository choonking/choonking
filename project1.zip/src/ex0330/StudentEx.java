package ex0330;

import java.util.Scanner;

class Student	{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	int getTotal()	{
		return this.kor+this.eng+this.math;
	}
	double getAverage() {
		return getTotal()/3.0;//(double)로 캐스팅해도됨 
	}
	void showInfo(){ 
		System.out.printf("%s %d %d %d %d %d %d %.1f\n",
				this.name, this.ban, this.no, this.kor, this.eng,
				this.math, this.getTotal(), this.getAverage());
	}
}








public class StudentEx {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		
		
		Student[] sArray = new Student[3];
		
		
		for (int i=0; i<sArray.length; i++) {
			//객체 생성후 학생 정보 입력
			System.out.println("학생 정보를 이름, 반, 번호, 국어, 영어, 수학 순서대로 입력하세요 ->");
			
			sArray[i] = new Student();
			sArray[i].name = scan.next();
			sArray[i].ban = scan.nextInt();
			sArray[i].no = scan.nextInt();
			sArray[i].kor = scan.nextInt();
			sArray[i].eng = scan.nextInt();
			sArray[i].math = scan.nextInt();
			
		}
		System.out.println("========================================");		
		System.out.println("학생이름 반 번호 국어 영어 수학 총점 평균");
		System.out.println("----------------------------------------");
		for(int i=0; i<sArray.length; i++) {
			sArray[i].showInfo();
		}
		System.out.println("========================================");	
		
		
			
		
	}

}
