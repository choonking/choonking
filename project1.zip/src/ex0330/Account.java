package ex0330;

class Account1	{
	int accountNo;
	String name;
	double balance; 
	void insert(int a, String n, double amnt) {
		this.accountNo=a;
		this.name = n;
		this.balance = amnt;
		
		
			
	}
	
	
	void deposit(double amnt) { // 해당 금액 입금후 잔액 출력
		
		balance+=amnt;
		checkBalance();
	
	}
	void withdraw(double amnt) { //해당 금액 출금후 잔액 출력
								//아닌 경우 부족 메세지 출력 후 잔액 출력
		{
		if (balance >= amnt) {
			balance-=amnt;
			
			} 
		else {
			System.out.println("잔액이 부족하여 출금할 수 없음 !");
		
		    }	
		checkBalance();
		}
		
	}
	void checkBalance() { // 현 잔액 출력
		
		System.out.printf("%s님의 잔액은 %.1f원입니다.\n", name, this.balance);
		
	}
	void display() { //계좌 정보 출력 
		System.out.println("---------------------");
		System.out.printf("계좌번호 : %d\n", accountNo);
		System.out.printf("예금주 : %s\n", name);
		System.out.printf("잔액 : %.1f원\n", balance);
		System.out.println("---------------------");
		
		
	}
	
	
}




public class Account {

	public static void main(String[] args) {
		Account1 acc = new Account1();
		acc.insert(11111, "코난", 10000.0);
		acc.display();
		acc.withdraw(20000.0);
		acc.deposit(30000.0);
		acc.withdraw(1500.0);
	
		
		
		

	}

}
