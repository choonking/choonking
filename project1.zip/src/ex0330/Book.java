package ex0330;

public class Book {
	String title;
	String author;
	int ISBN;
	//생성자 오버로딩
	//매개변수의 갯수가 틀림
	Book(){
		this(null,
			 null,
			 0);
		System.out.println("기본생성자 호출되었음");
	}
	Book(String title, int ISBN){
//		this.title = title;
//		this.ISBN = ISBN;
		this(title, null,ISBN); 
		System.out.println("매개변수 2개짜리");
		//자기 클래스 내부에서 다른 생성자 호출할때 사용
	}
	Book(String title, String author, int ISBN){
		this.title= title;this.author=author;this.ISBN=ISBN;
	}
	public static void main(String[] args) {
		Book b1 = new Book("날개","이상",3333);
//		System.out.printf("%s %s %d \n", b1.title, b1.author, b1.ISBN);
		Book b2 = new Book("bible", 1);
		System.out.printf("%s %s %d \n", b2.title, b2.author, b2.ISBN);
		Book b3 = new Book();
		System.out.printf("%s %s %d \n", b3.title, b3.author, b3.ISBN);
	}

}
