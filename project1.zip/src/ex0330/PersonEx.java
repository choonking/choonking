package ex0330;

class Person{
	String name;
	int age;
	Person(){} //기본 생성자, 
	//아무것도 초기화 하지 않고 
	//객체 생성시 호출됨
	Person(String name){ //매개변수 생성자
		//이름을 매개변수 name으로 초기화
		this.name = name;
		
	}
	String getName()	{
		return this.name;
	}
}

public class PersonEx {

	public static void main(String[] args) {
		Person aPerson = new Person("윤석열"); //객체를 생성 ->new 와 함께 생성자 호출 
		
//		Person bPerson = new Person("이재명"); 
		
//		Person cPerson = new Person("홍준표"); //여러 객체를 생성하기에 비효율적

		//배열 선언 
//		int[] iArray = new int[5]; //정수형 5개를 저장 할수 있는 이웃하는공간(배열 객체) 생성
								   //iArray가 참조하게함 
		String [] strArray = new String [5]; //문자형 5개를 저장하는 공간 생성	
		Person[] pa = new Person[10]; //**배열 객체
		
		
		for(int i=0; i<pa.length; i++)	{
			pa[i] = new Person();    //**Person 객체 생성 --> 생성자 호출  위에꺼랑 헷갈리면 안된다 
			pa[i].age=30+i;
			
		}
		for(int i=0; i<pa.length; i++)	{
			System.out.println(pa[i].age);
		}
		
		
		
		
		
		
	}

}
