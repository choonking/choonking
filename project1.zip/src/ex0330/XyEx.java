package ex0330;

import java.util.Scanner;

class Xy {
//두 점의 좌표를 입력받아 두 점의 중심점의 좌표를 소수 첫째자리까지 출력하는 프로그램을 작성하시오. 

	//점의 좌표는?(x, y) 10 5
	//점의 좌표는?(x, y) 12 36	
	
	//중심점의 위치 = (11.0, 20.5)
	int fir;
	int sec;
	
	
}






public class XyEx {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		Xy[] xArray = new Xy[2];
		for (int i=0; i<xArray.length; i++) {
			xArray[i] = new Xy();
			System.out.printf("점의 좌표는?(x,y) ");
			xArray[i].fir = scan.nextInt();
			xArray[i].sec = scan.nextInt();	
		}
		
		
			double sum_x = 0.0; double sum_y=0.0;
			for(int i=0; i<xArray.length; i++) {
				sum_x = sum_x+xArray[i].fir;
				sum_y = sum_y+xArray[i].sec;
		}
			double avg_x=0, avg_y=0;
					
			
			avg_x = sum_x/2;
			avg_y = sum_y/2;
			System.out.printf("%s = (%.1f, %.1f)" , "중심점의 위치" ,avg_x,avg_y);
		
			
		

	}

}
