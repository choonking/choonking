package ex0330;

public class DefaultConstructor {
	
	int x;
	//필드 값을 새로운 값을 설정
	public void setX(int x) { 
		this.x =x;
	}
	//현재 필드값을 반환
	public int getX()	{
		return this.x;

	}
	
	public DefaultConstructor(int x) {
		this.x =x;
	} // 생성자 예시에선 
								   //있으나 없으나 똑같긴함 필요시 배치해야함
	public static void main(String[] args) {
		DefaultConstructor p
		=new DefaultConstructor(2); //5번열에서 값을 가져옴 
		System.out.println(p.getX()); //2
		p.setX(3);  //3으로 바꿈
		System.out.println(p.getX()); //3
		p.setX(5);
		System.out.println(p.getX());

		

	}

}
