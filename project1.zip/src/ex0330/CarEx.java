package ex0330;

class Car	{
	
	
	//필드 선언
//	String company = "현대자동차";
//	String model;
//	String color;
//	int maxSpeed;
//	
//	Car(){}
//	
////	Car(String model)	{
////		this.model = model;
//	Car(String model){ //생성자1
//		this(model, "은색", 250);
//	}
//	Car(String model, String color) { //생성자2
//		this(model, color, 250);
//	}
//	Car(String model, String color, int maxSpeed) { //생성자3
//		this.model = model;
//		this.color = color;
//		this.maxSpeed = maxSpeed;
//	}
	int gas;
	
	void setGas(int gas) {
		this.gas = gas;
	}
	boolean isLeftGas()	{
		if (gas ==0) {
			System.out.println("gas가 없습니다.");
			return false; //false를 리턴하고 메소드 종료
		}    // ****
			System.out.println("gas가 있습니다.");
			return true; // true를 리턴하고 메소드 종료
	}
	
	//리턴값이 없는 메소드로 gas 필드값이 0이면 return 문으로 메소드를 종료
	void run()	{
		while (true)	{
			if (gas > 0) {
				System.out.println("달립니다. (gas잔량:" +gas + ")");
				gas-= 1;
			} else {
				System.out.println("멈춥니다. (gas잔량:" +gas + ")");
			    return;// 메소드 종료
			}
		}
	}
	
	
}








public class CarEx {

	public static void main(String[] args) {
		Car myCar = new Car();
//		System.out.println("car1.company : " + car1.company);
//		System.out.println();
//		
//		Car car2 = new Car("자가용");
//		System.out.println("car2.company : " + car2.company);
//		System.out.println("car2.model : " + car2.model);
//		System.out.println();
//		
//		Car car3 = new Car("자가용", "빨강");
//		System.out.println("car3.company : " + car3.company);
//		System.out.println("car3.model : " + car3.model);
//		System.out.println("car3.color : " + car3.color);
//		System.out.println("car3.maxSpeed : " + car3.maxSpeed);
		
//		Car car4 = new Car("택시", "검정", 200);
//		System.out.println("car4.company : " + car4.company);
//		System.out.println("car4.model : " + car4.model);
//		System.out.println("car4.color : " + car4.color);
//		System.out.println("car4.maxSpeed : " + car4.maxSpeed);
		
		myCar.setGas(5);
		if(myCar.isLeftGas())	{
			System.out.println("출발합니다.");
			
			myCar.run();		
		}
		System.out.println("gas를 주입하세요.");
			
		
	}

}
