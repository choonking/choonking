package ex0330;

import java.util.Scanner;

class Stud {
	//두 명의 이름과 국어, 영어 점수를 입력받아 과목별 점수의 평균을 구하여 출력하는 프로그램을 작성해 보시오.

    //(이름은 20자 이하이고 평균의 소수점 이하는 버림한다.)
	
	//Junho 88 100
	//Seonbin 95 96
	
	//Junho 88 100 
	//Seonbin 95 96 
	//avg 91 98
	
	String name;
	int kor;
	int eng;
	
}







public class StudEx {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		Stud[] sArray = new Stud[2];
		for (int i=0; i<sArray.length; i++)	{
			sArray[i]= new Stud();
			sArray[i].name = scan.next();
			sArray[i].kor = scan.nextInt();
			sArray[i].eng = scan.nextInt();
		}
		for(int i=0; i<sArray.length; i++) {
			System.out.printf("%s %d %d \n", 
					sArray[i].name, sArray[i].kor,  sArray[i].eng );
			
		}
		int sum_kor=0, sum_eng=0;
		for(int i=0; i<sArray.length; i++) {
			sum_kor = sum_kor+sArray[i].kor;
			sum_eng = sum_eng+sArray[i].eng;
		}

		int avg_kor=0, avg_eng=0;
		for(int i=0; i<sArray.length; i++) {
			avg_kor = sum_kor/2;
			avg_eng = sum_eng/2;

	}
		System.out.printf("%s %d %d" , "avg" ,avg_kor,avg_eng);
	}

}
