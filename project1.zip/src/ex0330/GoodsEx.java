package ex0330;

import java.util.Scanner;

class Goods	{
	String name;       //이름
	int price;         //가격
	int numberOfstock; //재고량
	int sold;	       //판매량
	
}











public class GoodsEx {

	public static void main(String[] args) {
//		Goods g =new Goods(); //이렇게 하지말고
		Scanner scan = new Scanner(System.in);
		System.out.println("상품명 가격 재고량 판매량");
		
		Goods[] gArray = new Goods[3]; //이렇게 하셈 
//		gArray[0] = new Goods();
//		gArray[1] = new Goods();
//		gArray[2] = new Goods();
		for(int i=0; i<gArray.length; i++) {
			gArray[i] = new Goods();
			gArray[i].name = scan.next();
			gArray[i].price = scan.nextInt();
			gArray[i].numberOfstock = scan.nextInt();
			gArray[i].sold = scan.nextInt();
			
		}
		
		for(int i=0; i<gArray.length; i++) {
			System.out.printf("%s %d원 %d개 %d개\n",
					gArray[i].name,  //name i번째에 저장되있는 
					gArray[i].price, //price i번째에 저장되있는
					gArray[i].numberOfstock,
					gArray[i].sold );
		}
		
		

	}

}
