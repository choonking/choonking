package ex0330;

import java.util.Scanner;

//두 명의 이름과 국어, 영어 점수를 입력받아 
//합계를 구하여 모두 출력하는 프로그램을 작성하시오. 
class Grade {
	String name;
	int kor;
	int eng;

	}


















public class GradeEx {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		Grade[] gArray = new Grade[2];
		for (int i=0; i<gArray.length; i++) {
			gArray[i] = new Grade();
			gArray[i].name = scan.next();
			gArray[i].kor = scan.nextInt();
			gArray[i].eng = scan.nextInt();
		
			
		}
		for(int i=0; i<gArray.length; i++) {
		System.out.printf("%s %d %d \n", 
				gArray[i].name, gArray[i].kor,  gArray[i].eng );
		}
		int sum_kor=0, sum_eng=0;
		
		for(int i=0; i<gArray.length; i++) {
			sum_kor = sum_kor+gArray[i].kor;
			sum_eng = sum_eng+gArray[i].eng;
		}
		System.out.printf("%s %d %d\n", "합계", sum_kor, sum_eng); 
	}
}
