package ex0330;

public class Calculator {
	
	void powerOn() {				//기능적인 부분을 메소드로 만든다
		System.out.println("전원을 켬"); // 전원 on기능
	}
	void powerOff() {
		System.out.println("전원을 끔"); // 전원 off기능
	}
	int plus(int x, int y) {
		System.out.println("aa");// 더하기 연산 기능
		return x+y;
		
	}
	double divide(int x, int y) {   // 나누기 연산 기능
		return (double)x/(double)y;	
	}

}
