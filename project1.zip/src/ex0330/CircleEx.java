package ex0330;

class Circle {
	public double radius = 1.0;
	public Circle() {}
	public Circle(double radius)	{ //필드를 초기화 한다
		this.radius = radius;
	}
	public double getRadius() { //입력이 없다
		return this.radius;
	}
	public void setRadius(double radius) { //입력이 있다
		this.radius = radius;
	}
	public double getArea() {
		return radius*radius*Math.PI;
	}
	public double getCircumference() {
		return 2 * Math.PI *radius;
	}
	public String toString() {
		return String.format("Circle[radius=%.1f", radius);
	}
}

public class CircleEx {

	public static void main(String[] args) {
		Circle c1 = new Circle(); // 1.0
		Circle c2 = new Circle(2.0);
		System.out.printf("%s의 둘레는 %.2f, 면적은 %.2f\n",c1.toString(),c1.getCircumference(),c1.getArea());
		System.out.printf("%s의 둘레는 %.2f, 면적은 %.2f,",c2.toString(),c2.getCircumference(),c2.getArea());
		
//		c1.toString() c1.getCircumference() c1.getArea()

		
	}

}
