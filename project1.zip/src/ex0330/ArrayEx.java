package ex0330;

import java.util.Scanner;

class Array	{
	String name;
	String phone;
	String loc; 

}











public class ArrayEx {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);

		Array[] sArray = new Array[1];

		for (int i=0; i<sArray.length; i++) {


			sArray[i] = new Array();		
			sArray[i].name = scan.next();
			sArray[i].phone = scan.next();
			sArray[i].loc = scan.next();

		}
		for (int i=0; i<sArray.length; i++) {
			System.out.printf("name : %s\n",sArray[i].name); 
			System.out.printf("tel : %s\n",sArray[i].phone); 
			System.out.printf("addr : %s", sArray[i].loc);

		}

	}
}
