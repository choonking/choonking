package ex0330;

public class CalculatorEx {

	public static void main(String[] args) {
		Calculator myCal = new Calculator();
		myCal.powerOn();
		System.out.println(myCal.plus(5,6));
		System.out.println(myCal.divide(10,4));
		
		myCal.powerOff();

	}

}
