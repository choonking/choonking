package ex0330;

class Rectangle {
	//밑변 + 높이*2 = 둘레
	//밑변 x 높이 = 면적
	public double length= 1.0;
	public double width= 1.0;
	public Rectangle()	{}
	public Rectangle(double length, double width) { //필드를 초기화
	this.length = length;
	this.width = width;
	}
	public double getLength() {	//length값 획득
		return this.length;
	}
	public void setLength(double length) { //length값 세팅
		this.length = length;
	}
	public double getWidth() {
		return this.width;
	}
	public void setWidth(double width) {	
		this.width = width;
	}
	
	public double getArea() {
		return length*width;
		
	}
	public double getPerimeter() {
		return (length+width)*2;
		
	}
	public String toString() { //투스트링 어케 쓰는거노 
		return String.format("Rectangle[length=%.1f, width=%.1f", length, width);
		
	}
	
	

}









public class RectangleEx {

	public static void main(String[] args) {	
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(3.0, 15.0);
		System.out.printf("%s의 둘레는 %.2f, 면적은 %.2f\n",r1.toString(),r1.getPerimeter(),r1.getArea());
		System.out.printf("%s의 둘레는 %.2f, 면적은 %.2f\n",r2.toString(),r2.getPerimeter(),r2.getArea());
	}
	
}
		
