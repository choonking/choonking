package temp;


class AA{
	int def;
	protected int pro;
	private int pri;
	public int pub;
}

class BB extends AA {
	void set() {
		def=1;
		pro=2;
		//pri=3;
		pub=4;
	}
}
public class ABEx {

	public static void main(String[] args) {
		BB b = new BB();
		b.set();
		System.out.println(b.def);
		System.out.println(b.pro);
		System.out.println(b.pub);
	

	}

}
