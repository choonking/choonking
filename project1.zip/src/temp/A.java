package temp;

import java.util.*;// java.util에 있는 모든 클래스를 임포트 

//import java.util.Scanner;
public class A {
	
	public static void main(String[] args) {
		
		
		String str = "Hello"; //String class
		str.length(); //String이 기본 제공 되는 패키지에 속한 클래스라 import 필요없음
//		java.util.Scanner scan = new java.util.Scanner(System.in); //java.util.Scanner
		Scanner scan = new Scanner(System.in);
	}

}
