package Ex0324;

import java.util.Scanner;

public class PraMethod01 {

	public static void main(String[] args) {
//		method1();
//	    System.out.println(method2());
//		double num=method2();
//		System.out.println("method2가 반환한 값은 " +num);	
		
		Scanner scan = new Scanner(System.in);		
		int num = scan.nextInt();
		System.out.print(num);
	}
	public static void method1() { //본체 -> body
		System.out.println("나는 void형 메소드");
	}
	public static double method2() {
		System.out.println("나는 반환값이 있는 메소드");
		return 1.9; // return문은 마지막에 작성, 할일 마치고 끝
		
	}
	
}
