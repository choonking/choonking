package Ex0324;

import java.util.Scanner;

public class PraMethod03 {

	public static void main(String[] args) {
		// 합과 차를 각각 리턴하는 함수를 작성한 후 
		//두 정수를 입력받아 함수를 호출하여 두 수의 합과 차를 출력하는 프로그램을 작성하시오.
	//	두 수의 합 = 40
	//	두 수의 차 = 20		
	Scanner scan = new Scanner(System.in);
	int a = scan.nextInt();
	int b = scan.nextInt();
	System.out.println("두 수의 합 = " +sum(a,b));
	System.out.print("두 수의 차 = " +minus(a,b));
	}
	public static int sum(int a,int b)	{
		return a+b;
	}
	public static int minus(int a,int b)	{
	if(a>=b) {
		return a-b;
	}
	else {
		return b-a;
	}
		
		
	}

}
