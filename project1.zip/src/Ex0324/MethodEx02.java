package Ex0324;

public class MethodEx02 {
	//클래스 내부, 다른 메소드 영역의 밖에 만들어야함  

	public static void main(String[] args) {
		sum(1, 2);			//메소드 호출
		minus(1, 4);
		multi(5, 4);
		divide(10, 3);
		remainder(10,3);
	}
		public static void sum(int a, int b) { //void로 선언되어있으면 return문 필요없음 
			System.out.printf("%d + %d = %d\n", a, b, a+b);
	}
		public static void minus(int a, int b) {  
			System.out.printf("%d - %d = %d\n", a, b, a-b);
	}
		public static void multi(int a, int b) { 
			System.out.printf("%d * %d = %d\n", a, b, a*b);
	}
		public static void divide(int a, int b) { 
			System.out.printf("%d / %d = %d", a, b, a/b);
	}
		public static void remainder(int a, int b) { 
			System.out.printf("%d %% %d = %d", a, b, a%b);
	}
		


}
