package Ex0324;

import java.util.Scanner;

public class PraWhile08 {

	public static void main(String[] args) {
		//삼각형의 밑변의 길이와 높이를 입력받아 넓이를 출력하고, 
		//"Continue? "에서 하나의 문자를 입력받아 그 문자가 'Y' 나 'y' 이면 작업을 반복하고 다른 문자이면 종료하는 프로그램을 작성하시오.
		//(넓이는 반올림하여 소수 첫째자리까지 출력한다.)
		//입출력
		//Base = 11
		//Height = 5
		//Triangle width = 27.5
		//Continue? Y  (y)       ===까지 반복===
		//Base = 10
		//Height = 10
		//Triangle width = 50.0
		//Continue? N
		Scanner scan = new Scanner(System.in);
		int base = 0, height=0;	//밑변, 높이
		double area=0.0; 		// 면적 저장용
		boolean flag = true; 	//열닫용
		String ans = "";
		while(flag) {
			System.out.print("Base = ");
			base = scan.nextInt();
			System.out.print("Height = ");
			height = scan.nextInt();
			area = base*height/2.0;
			System.out.printf("Triangle width = %.1f\n", area);
			System.out.print("Continue? ");
			ans= scan.next();
			if(ans.equals("Y")|| ans.equals("y")) {	
			}
			else {
				flag=false;
				}
		}
	}
}
