package Ex0324;

public class MethodEx {

	public static void main(String[] args) { // 메인 메소드 
		// TODO Auto-generated method stub
		System.out.println("두수의 합은: " +sum(1,2)); //메소드 호출(call)
		System.out.println("두수의 차는: " +minus(1,2));
		System.out.println("두수의 곱은: " +multi(1,2));
		System.out.println("두수의 몫은: " +divide(1,2));
	}//메인의 끝
	//두개의 정수를 입력받아서 합을 구한 다음, 그 결과를 반환하는 메소드 만들기
	//메소드 이름 sum
	
	public static int sum(int a,int b){ // 메소드 선언
		return a+b; // 반환하다 (출력에 갖다 쓴다)
	}	//sum의 끝
	public static int minus(int a, int b){
		return a-b;
	}
	public static int multi(int a,int b){ // 메소드 선언
		return a*b; // 반환하다 (출력에 갖다 쓴다)
	}
	public static int divide(int a,int b){ // 메소드 선언
		return a/b; // 반환하다 (출력에 갖다 쓴다)
	}
	
	
}
