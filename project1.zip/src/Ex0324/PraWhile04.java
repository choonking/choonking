package Ex0324;

import java.util.Scanner;

public class PraWhile04 {

	public static void main(String[] args) {
		// 정수를 계속 입력을 받다가 0이 입력되면 0을 제외하고 이전에 입력된 자료의 수와 합계,
		// 평균을 출력하는 프로그램을 작성하시오. (평균은 반올림하여 소수 둘째자리까지 출력한다.)

		Scanner scan = new Scanner(System.in);
		int num= scan.nextInt(); 	//선언
		int a = 0;					//0부터 카운트
		int sum = num;				//합계 -> 첫입력 데이터 부터 세야하므로 num
		double avg =0; 				//평균 
		while(num!=0)	{ 			//num=0이 아닐때 반복
			num= scan.nextInt();	//num=0이 아니면 또 입력
			sum+=num;				//합계=num에 sum을 더함
			a++;					//자료의 개수 카운트
				
		}	
		avg=sum/(double)a;			//평균-> 합계를 a로 나눴고 double형으로 변환함
		System.out.printf("입력된 자료의 개수 = %d\n",a);		// 카운트된 자료 개수 a
		System.out.printf("입력된 자료의 합계 = %d\n",sum );	// sum에 num+sum 누적된 데이터가 저장되있음
		System.out.printf("입력된 자료의 평균 = %3.2f", avg);// *평균은 다 끝나고 나서 계산하기 때문에 반복문 밖에 나와있음
	}

}
