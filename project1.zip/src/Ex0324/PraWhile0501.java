package Ex0324;

import java.util.Scanner;

public class PraWhile0501 {

	public static void main(String[] args) {
		int num1=0, num2=0;
		String op = "";
		int result = 0;
		Scanner scan = new Scanner(System.in);
		boolean flag = true;
		while(flag) {
			System.out.print("첫 번째 숫자 입력 : ");
			num1 = scan.nextInt();
			System.out.print("두 번째 숫자 입력 : ");
			num2 = scan.nextInt();
			System.out.print("연산 기호 입력 : ");
			op = scan.next();
			switch(op)	{
			case "+" : //op는 부호가 들어가야 하기 때문에 String으로 선언됨, 따라서 case 1 : 같은건 못쓴다.
				result = num1+num2;
				System.out.printf("계산 결과는 %d\n", result);	
				break;
			case "-" :
				result = num1-num2;
				System.out.printf("계산 결과는 %d\n", result);	
				break;
			case "*" :
				result = num1*num2;
				System.out.printf("계산 결과는 %d\n", result);	
				break;
			case "/" :
				result = num1/num2;
				System.out.printf("계산 결과는 %d\n", result);	
				break;
			case "quit" :
				flag=false;	// flag=false 해서 맨위에 while 옆에 있는 flag가 닫혀버림 flag(true)=열기 (false)=닫기
				break;
			default:
				System.out.println("연산 기호를 잘못 입력하셨습니다.");
		
				}
		}
	}
}
