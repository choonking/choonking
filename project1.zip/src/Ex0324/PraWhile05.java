package Ex0324;

import java.util.Scanner;

public class PraWhile05 {

	public static void main(String[] args) {
		int num1=0, num2=0; //입력 숫자 저장용
		String op = ""; //연산기호 입력용
		int result = 0; //연산결과 저장용
		Scanner scan = new Scanner(System.in);
		boolean flag = true;
		while(flag)	{
			System.out.print("첫 번째 숫자 입력 : ");
			num1 = scan.nextInt();
			System.out.print("두 번째 숫자 입력 : ");
			num2 = scan.nextInt();
			System.out.print("연산 기호 입력 : ");
			op = scan.next();
			if(op.equals("+"))	{
				result = num1+num2;
				System.out.printf("계산 결과는 %d\n", result);
			}
			else if (op.equals("-"))	{
				result = num1-num2;
				System.out.printf("계산 결과는 %d\n", result);
			}
			else if (op.equals("*"))	{
				result = num1*num2;
				System.out.printf("계산 결과는 %d\n", result);
		}
			else if (op.equals("/"))	{
				result = num1/num2;//몫만 구하는 결과
				System.out.printf("계산 결과는 %d\n", result);
			}
			else if (op.equals("quit"))	{
				flag=false;
			}
			else {
				System.out.println("연산 기호 입력이 잘못됐습니다.");
			}
			
		}
  }

}
