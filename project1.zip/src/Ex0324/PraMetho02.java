package Ex0324;

import java.util.Scanner;

public class PraMetho02 {

	public static void main(String[] args) {
		// 정수를 전달받아 출력 예와 같이 '*'로 이루어진 직각삼각형을
		// 출력하는 함수를 작성하고 입력받은 정수를 전달하여 출력하는 프로그램을 작성하시오.
		
		//입력 5
		//*
		//**
		//***
		//****
		//*****
		
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt(b);
		System.out.printf("*\n");
		System.out.printf("**\n");
		System.out.printf("***\n");
		System.out.printf("****\n");
		System.out.printf("*****");
			
		 
		
		
	
	}
	private static String star(int i) {
		for(int z=1; z<=i; z++)
			System.out.println();
		
		
	}

}
