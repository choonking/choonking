package Ex0324;

import java.util.Scanner;

public class PraWhile03 {

	public static void main(String[] args) {
		//한 개의 정수를 입력받아 양수(positive integer)인지 음수(negative number)인지 출력하는 
		//작업을 반복하다가 0이 입력되면 종료하는 프로그램을 작성하시오.
		//* 입출력예의 진한글씨는 출력값입니다.
		//number? 10
		//positive integer
		//number? -10
		//negative number
		//number? 0
		Scanner scan = new Scanner(System.in);
		System.out.print("number? "); //입력하기전 안내문
		int num= scan.nextInt();	  //정수를 입력받음
		

		while(num!=0)	{			  //num이 0이 아닐때 반복함

			if(num>0)			{	  //num이 양수일 때 출력할 문구를 입력
				System.out.println("positive integer"); 
			}
			else				{	  //num이 0이 아니면서 양수도 아닐때 = 음수일 때 출력할 문구를 입력
				System.out.println("negative number");
			}
			System.out.print("number? ");	//0이 아닌수가 나왔을때 다시 물어봄
			num= scan.nextInt();			//다시 정수를 입력 받음
		}

	}

}
