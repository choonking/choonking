package Ex0324;

public class WhileEx {

	public static void main(String[] args) {
//		int i=1;  					//1부터 시작
//		while(i<11) { 				//11보다 작을때까지
//			System.out.println(i);  //1를 출력
//			i++;
//	}
//		int i = 1; //1부터 1씩 증가
//		int sum=0; //0부터 증가
//		while(i<11) {
//			sum=sum+i;
//			i++;
//		}
//		System.out.println("1부터 10까지의 합은 "+sum);
//		System.out.printf("1부터 10까지의 합은 %d", sum);
//		System.out.printf("현재 i는 %d", i); //11까지 증가해서 조건이 거짓이 되어 멈춰서 나와버림
//		int i=1;
//		int sum=0;
//		do{        //*한번만 실행할때 쓰면 do while 쓰는것 괜찮다. 
//		sum+=i;
//		i++;
//		}while(i<=10);
//		System.out.println("1부터 10까지의 합은 "+sum);
		
		int even=0;
		int odd=0;
		for(int i = 1; i<=100; i++)	{
			if(i%2 == 1) {
				odd +=i;
				continue;
			}
			else	{
				even+=i;
				}
		}
		System.out.println("1부터 100까지 홀수의 합은 "+odd);
		System.out.println("1부터 100까지 짝수의 합은 "+even);
		
	}
}


