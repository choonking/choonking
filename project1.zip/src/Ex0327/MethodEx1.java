package Ex0327;

public class MethodEx1 {

	public static void main(String[] args) {
		// 1부터 1000까지의 합을 구하라
		int sum=0;
			
//	sum=0;
//	for(int i=1; i<=1000; i++) {
//		sum+=i;
//}
//
//	System.out.printf("1부터 1000까지의 합은 %d", sum);
	
	int result = sumN(1000);
	System.out.printf("1부터 1000까지의 합은 %d \n", result);
	result = sumN(10);
	System.out.printf("1부터 10까지의 합은 %d \n", result);
	result = sumN(300);
	System.out.printf("1부터 100까지의 합은 %d \n", result);
	result = sumMN(10, 300);
	System.out.printf("m부터 n까지의 합은 %d \n", result);   // 모듀라~
	sumAB(1,100);
	} //main block
	
	public static int sumN(int n){ //1부터 n까지의 합을 구한 다음 반환 *모듈화!
		int sum = 0 ;
		for(int i=1; i<=n; i++) {
			sum+=i;
		}
		return sum;
	
	}
	
	public static int sumMN(int m,int n){ //1부터 n까지의 합을 구한 다음 반환 
		int sum = 0 ;
		for(int i=m; i<=n; i++) {
			sum+=i;
		}
		return sum;
	}
	public static void sumAB(int a,int b){ //a부터 b까지의 합을 구한 다음, 결과 출력 
		int sum = 0 ;
		for(int i=a; i<=b; i++) {
			sum+=i;
		}
		System.out.printf("%d에서부터 %d까지의 합은 %d", a,b,sum);
	
	}
}

