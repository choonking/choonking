package Ex0327;

public class StringEx1 {

	public static void main(String[] args) {
//		String a = "Hello";
//		String b = "Java";
//		String c = "Hello";
//		String d = new String("Hello");
//		String e = new String("Java");
//		String f = new String("Java");
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(e);
//		System.out.println(f);
//		
//		System.out.println(a.equals(c)); //a,c는 같다
//		System.out.println(a.equals(d)); //a,d는 같다
//		//equals는 문자열의 내용이 같은가를 비교함 
//		
//		// == : 객체를 비교할 경우, 왼쪽 레퍼런스 참조하는 객체가
//		// 오른쪽 레퍼런스가 참조하는 객체가 같은가? *객체를 검사함  
//		System.out.println(a==c);		//true
//		System.out.println(a==d);		//false ???}
//		System.out.println("ba".compareTo("bo"));
//		String a = "java";
//		String b = "jasa";
//		int res = a.compareTo(b);
//		if(res == 0)
//			System.out.println("the same");
//		else if(res<0)
//			System.out.println(a+"<"+b);
//		else
//			System.out.println(a+">"+b);
	
//			System.out.println("Hello".charAt(4)); //charAt(?)문자열중에 한자리만 가져오는 거, ?=문자열 위치: 예시는 왼쪽부터0~4까지있다
//			System.out.println("Hel__lo".indexOf('l',3)); //특정문자의 위치, 위에꺼랑 반대임 없으면 -1리턴함 
//			System.out.println("Hell".concat("Java")); //결합(+연산자와 역할이 같음) 
//			System.out.println("Hello".contains("lo")); //이거 포함되어있는지 봄 
//			System.out.println("Hello Java".length()); //문자열 갯수를 리턴함
//			System.out.println("Hello Java".replace("o", "")); //그 결과를 문자열로 바꿔치기해서 리턴함 
//			System.out.println("Hello Java".substring(4));  //(?):?자리이후부터 출력
//			System.out.println("Hello Java".toLowerCase()); //모두 소문자로
//			System.out.println("Hello Java".toUpperCase()); //모두 대문자로
//			System.out.println("     \t\t\t\tHello     Java    ".trim());
//			System.out.println("     \t\t\t\tHello     Java    ");
			String s1 = "Hell";	
			String s2 = "Java";
			System.out.println(s1);
			String s3 = s1.concat(s2);
			System.out.println(s1);
	
	}
}