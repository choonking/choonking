package Ex0327;

public class MethodEx2 {
	static int b=2; //전역변수(global variable)

	public static void main(String[] args) {
		method1();
		method2();
		System.out.println("main()의 내부"+b);
	}	 
	public static void method1(int i)	{  //매개변수=지역변수
		int a; //지역 변수(local variable)
		a=1;
		System.out.println("method1()의 내부"+j);
	}
	public static void method2(int j)	{
		System.out.println("method2()의 내부"+i);
	}

}
