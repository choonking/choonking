package Ex0327;

import java.util.Scanner;

public class PracMethod1 {

	public static void main(String[] args) {
		
//		서로 다른 두 개의 정수가 주어진다.
//		두 정수를 입력받아 큰 수는 2로 나눈 몫을 저장하고 작은 수는 2를 곱하여 저장한 후 출력하는 
//		프로그램을 작성하시오.
//		(참조에 의한 호출을 이용한 함수를 작성하여 값을 수정하고 출력은 메인함수에서 한다.)
		Scanner scan = new Scanner(System.in);
		int fir = scan.nextInt();
		int sec = scan.nextInt();
//100 500
//200 250
calculate();
calculate1(fir, sec);
		
		
	}
	
	
	public static void calculate1(int fir, int sec){ // 2개의 정수를 입력받음
		//큰 수는 2로 나누고 몫을 저장 후 출력, 작은 수는 2를 곱하여 저장 후 출력
		Scanner scan = new Scanner(System.in);
		
			if (fir>=sec) {
				System.out.printf("%d %d\n", fir/2,sec*2);
			}
				
				else { //sec이 fir보다 큰경우
					System.out.printf("%d %d\n", fir*2,sec/2);
				}
	}
			
	public static void calculate(){ // 2개의 정수를 입력받음
					//큰 수는 2로 나누고 몫을 저장 후 출력, 작은 수는 2를 곱하여 저장 후 출력
		Scanner scan = new Scanner(System.in);
		int fir = scan.nextInt();
		int sec = scan.nextInt();
		if (fir>=sec) {
		System.out.printf("%d %d\n", fir/2,sec*2);
						}
							
		else { //sec이 fir보다 큰경우
		System.out.printf("%d %d\n", fir*2,sec/2);
		}
	}
	
}