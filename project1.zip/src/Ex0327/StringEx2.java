package Ex0327;

public class StringEx2 {

	public static void main(String[] args) {
		//다음과 같이 “우리나라 대한민국!”을 문자형 배열에 초기화하고
		// 길이를 구하여 다음과 같이 출력하는 프로그램을 작성하시오. 
		//우리나라 대한민국!
		//위 문자열의 길이는 ??입니다.
		String kor = ("우리나라 대한민국!");
		System.out.println(kor);

		System.out.printf("위 문자열의 길이는 %d입니다.",kor.length());
	}

}
