package Ex0327;

import java.util.Scanner;

public class PracString2 {

	public static void main(String[] args) {
//공백을 포함하여 100글자 이하의 문자열(문장)을 입력받아 공백을 기준으로 줄을 바꾸어 출력하는 프로그램을 작성하시오. 
		Scanner scan = new Scanner(System.in);
		String a = scan.nextLine();
		String b = " ";
		System.out.printf(a.replace(b, "\n"));
		
		}
}


