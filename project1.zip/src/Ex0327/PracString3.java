package Ex0327;

import java.util.Scanner;

public class PracString3 {

	public static void main(String[] args) {
		// 5개 이상 100개 이하의 문자로 된 단어를 입력받은 후 앞에서부터 5자를 출력하는 프로그램을 작성하시오.
		
//입 AbCdEFG //출 AbCdE
		Scanner scan = new Scanner(System.in);
		String a = scan.nextLine();
		String let1 = a.substring(0);
		String let2 = a.substring(0,5);
		
		System.out.print(let2);

	}
	

}
