package Ex0327;

public class OpEx1 {

	public static void main(String[] args) {
		int x = 5;
		int y = 13;
//		int s ;
//		if(x>y) {
//			s=1;
//		}
//		else	{
//			s= -1;
//		}
//		System.out.println("s : "+s);
		int s = (x>y)? 1: -1; //조건연산자 <이 조건이 참이면 1, 거짓이면 -1>
		System.out.println("s : "+s);
	}

}
