package Ex0327;

import java.util.Scanner;

public class PraMethod2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		// main에서 호출후 출력
		while(true) {
		System.out.println("두개의 정수를 입력하세요.");
		int fir = scan.nextInt();
		int sec = scan.nextInt();
		System.out.printf("%d와 %d의 합은 %d\n", fir, sec, add(fir,sec));
		System.out.printf("%d와 %d의 차는 %d\n", fir, sec, minus(fir,sec));
		System.out.printf("%d와 %d의 곱은 %d\n", fir, sec, multi(fir,sec));
		System.out.printf("%d 나누기 %d은 %3.2f", fir, sec, divide(fir,sec));
		}
	}
	public static int add(int i, int j)	{
	return i+j;
				
	}

	public static int minus(int i, int j)	{
	return i-j;
		
}

	public static int multi(int i, int j)	{
	return i*j;
		
}
	public static double divide(int i, int j)	{
	return (double)i/j;
		
	}
	

}
