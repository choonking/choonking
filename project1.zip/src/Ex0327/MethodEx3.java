package Ex0327;

public class MethodEx3 {

	public static void main(String[] args) {
		
	public static void printStar(int n) {
		for (int i=1; i<=n; i++)	{
			for(int j=2; j<=i; j++) {
				System.out.println();
			}
		}
				
	
	
	

}
