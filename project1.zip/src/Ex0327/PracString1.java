package Ex0327;

import java.util.Scanner;

public class PracString1 {

	public static void main(String[] args) {
//		문자열을 입력받은 뒤 그 문자열을 이어서 두 번 출력하는 프로그램을 작성하시오.
//		문자열의 길이는 100이하이다.
//입 ASDFG
//출 ASDFGASDFG
		Scanner scan = new Scanner(System.in);
		String a = scan.next();
//		System.out.print(a);
//		System.out.print(a);
		
//		문자열을 입력받아서 문자열의 길이를 구하고 입력받은 역순으로 출력하는 프로그램을 작성하시오. 	
		System.out.printf("입력받은 문자열의 길이는 %d입니다.\n",a.length());
		
		String reverse = "";
				
		for(int i=a.length()-1; 0<=i; i--) {
			reverse += a.charAt(i); //reverse 변수에 대입(문자열결합)
				}
				System.out.println(reverse);
			}

	
	}


