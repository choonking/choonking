package ex0406;

import java.util.ArrayList; //컬렉션 배우는중 

public class ArrayListEx {

	public static void main(String[] args) {
		/*
		 * String[] strArray = new String[2];
		 *  strArray[0]="Hello"; 
		 *  strArray[1]="Java";
		 */
		//크기가 늘어나야 할 경우, 새로 만들어서 복사해야됨 
		//ArrayList 크기가 변함
		ArrayList<String> al = new ArrayList<String>();
		al.add("Hello"); //0
		al.add("Java"); //1
		al.add("HELL"); //2


		//System.out.println("=========================");
		//System.out.println(al.size()); // 3개 데이터 차있어서 3을 리턴함 
		for(int i=0; i<al.size(); i++) {
		//	System.out.println(i+" : "+al.get(i));
		}
		//System.out.println("2번 인덱스에 삽입================");
		al.add(2,"Stupid");

		for(int i=0; i<al.size(); i++) {
		//	System.out.println(i+" : "+al.get(i));
		}
		// al.add(5, "Study");  빈 공간에 추가할수 없음
		//System.out.println("1번 인덱스 Hi 삭제 -------------");
		al.remove(1);
		for(int i=0; i<al.size(); i++) {
		//	System.out.println(i+" : "+al.get(i)); //빈공간 없애고 땡겨짐 
		}
		//System.out.println(" Stupid 삭제 -------------");
		al.remove("Stupid");
		for(int i=0; i<al.size(); i++) {
		//	System.out.println(i+" : "+al.get(i)); //빈공간 없애고 땡겨짐 
		}
		
		//al.remove(6);  빈 공간에 있는걸 지울수 없음 
		
		System.out.println(al.indexOf("HELL"));
		
		System.out.println("비어있노?" + al.isEmpty());
	}
	
	




//		al.add("허경영"); //2
//		al.add("윤석열"); //3
//		al.add("박근혜"); //4
//		System.out.println(al.get(0));
//		System.out.println(al.get(1));
//		System.out.println(al.get(2));
//		System.out.println(al.get(3));
//		System.out.println(al.get(4));
//		al.add("Hello"); //5
//		al.add("Java");
//		al.add("허경영");
//		al.add("윤석열");
//		al.add("박근혜"); //9
//		System.out.println(al.get(5));
//		System.out.println(al.get(6));
//		System.out.println(al.get(7));
//		System.out.println(al.get(8));
//		System.out.println(al.get(9));


}


