package ex0406;

import java.util.StringTokenizer;

public class StringBufferEx1 {

	public static void main(String[] args) {
		String query = "name=허경영&add=서울&age=58&축지법";
		StringTokenizer st = new StringTokenizer(query, "&=");
//		System.out.println("토큰이 남아있니?" + st.hasMoreTokens());
//		System.out.println(st.nextToken());
//		System.out.println("토큰이 남아있니?" + st.hasMoreTokens());
//		System.out.println(st.nextToken());
//		System.out.println("토큰이 남아있니?" + st.hasMoreTokens());
//		System.out.println(st.nextToken());
//		System.out.println("토큰이 남아있니?" + st.hasMoreTokens());
//		System.out.println(st.nextToken());
//		System.out.println("토큰이 남아있니?" + st.hasMoreTokens());
//		System.out.println(st.nextToken());
//		System.out.println("토큰이 남아있니?" + st.hasMoreTokens());
	
		while(st.hasMoreTokens()) {
			System.out.println(st.countTokens()); //현재 남아있는 토큰 개수를 반환함
			System.out.println(st.nextToken());   
		}
	}

}
