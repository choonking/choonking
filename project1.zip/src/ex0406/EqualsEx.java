package ex0406;

class Member {
	public String id;
	
	public Member(String id) {
		this.id = id;
		
	}
@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member target) {
			if(id.equals(target.id)) {
				return true;
			}
		}
		return false;
	}
}






public class EqualsEx {

	public static void main(String[] args) {
		Member obj1 = new Member("blue");
		Member obj2 = new Member("blue");
		Member obj3 = new Member("red");
		
		if(obj1.equals(obj2)) {
			System.out.println("obj1과 obj2는 동등합니다.");
		}else {
			System.out.println("obj1과 obj2는 동등하지 않습니다.");
		}
		
		if(obj1.equals(obj3)) {
			System.out.println("obj1과 obj3은 동등합니다.");
		}else {
			System.out.println("obj1과 obj3은 동등하지 않습니다.");
		}
		
	
	}

}
/*위 코드는 Member 클래스에서 equals 메서드를 오버라이딩하여 객체의 id 값이 같으면 동일한 객체로 판별하는 예제입니다.
Member 클래스는 하나의 필드인 id 값을 가지고 있으며, 생성자를 통해 객체를 생성할 때 id 값을 초기화합니다.
equals 메서드는 Object 클래스의 equals 메서드를 오버라이딩한 것으로, 매개변수로 전달받은 객체가 Member
 클래스의 인스턴스인지 확인한 후, id 값이 같으면 true를 반환하고, 그렇지 않으면 false를 반환합니다.
메인 메서드에서는 Member 클래스의 인스턴스 obj1, obj2, obj3를 생성하고, obj1과 obj2, obj1과 obj3을 비교하여 결과를 출력합니다.
 obj1과 obj2는 id 값이 같으므로 동등하다는 결과가 출력되고, obj1과 obj3은 id 값이 다르므로 동등하지 않다는 결과가 출력됩니다.*/
