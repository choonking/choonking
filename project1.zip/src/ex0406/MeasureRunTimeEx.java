package ex0406;

public class MeasureRunTimeEx {

	public static void main(String[] args) {
	
		int sum = 0 ;
		long time1 = System.nanoTime();
		for(int i=1; i<=100000; i++) {
			sum+=i;
		}
		long time2 = System.nanoTime();
		System.out.println("1부터 100000까지의 합 : " +sum);
		System.out.println("처리에 걸린 시간은" +(time2-time1)+"나노초가 걸렸음");
	}

}
//해당 코드는 1부터 100000까지의 합을 구하고, 그 처리 시간을 측정하는 예제입니다.