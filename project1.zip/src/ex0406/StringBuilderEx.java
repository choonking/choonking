package ex0406;

public class StringBuilderEx {

	public static void main(String[] args) {
		String data = new StringBuilderEx()
				.append("DEF")
				.insert(0, "ABC")
				.delete(3,4)
				.toString();
		System.out.println(data);

	}

}
