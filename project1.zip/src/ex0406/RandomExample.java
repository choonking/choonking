package ex0406;

import java.util.*;

public class RandomExample {
    public static void main(String[] args) {
        int[] lotto = new int[6];
        Random random = new Random();
        Map<Integer, Integer> countMap = new HashMap<>();

        // 100번 반복해서 랜덤 숫자 추출하고, 중복된 숫자 개수 세기
        for (int i = 0; i < 7777; i++) {
            for (int j = 0; j < lotto.length; j++) {
                int num = random.nextInt(45) + 1;
                lotto[j] = num;
                countMap.put(num, countMap.getOrDefault(num, 0) + 1);
            }
        }

        // 중복 횟수가 많은 순으로 정렬하기 위해 리스트에 담고 정렬
        List<Map.Entry<Integer, Integer>> countList = new ArrayList<>(countMap.entrySet());
        countList.sort(Map.Entry.<Integer, Integer>comparingByValue().reversed());

        // 가장 많이 나온 숫자 6개 출력
        System.out.println("가장 많이 나온 숫자 6개:");
        for (int i = 0; i < 6; i++) {
            System.out.println(countList.get(i).getKey() + " (" + countList.get(i).getValue() + "회)");
        }
    }
}