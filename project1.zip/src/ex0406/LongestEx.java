package ex0406;

import java.util.ArrayList;
import java.util.Scanner;

public class LongestEx {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<String> list = new ArrayList<String>();
		//입력 받아 바로 어레이리스트에 저장 
		
		for (int i=0; i<4; i++) {
			System.out.print("이름을 입력하세요>>");
			list.add(scan.next());
		}
		//출력 
		for(int i=0; i<list.size(); i++) {
			System.out.print(list.get(i)+" ");
		}
		System.out.println();
		//length(); -> 문자열 길이 반환 
		String longest = list.get(0);
		for(int i=0; i<list.size(); i++) {
			if(longest.length()<list.get(i).length()) {
				longest = list.get(i);   //롱기스트가 겟i의 길이보다 작다면 롱기스트는 겟i로 한다 
			}
		}
		
		System.out.println("가장 긴 이름은"+longest);  //롱기스트가 제일 길음 
	}

}
