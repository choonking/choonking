package ex0406;

import java.util.ArrayList;
import java.util.List;

class Board{
	private String subject;
	private String content;
	private String writter;
	
	 public Board(String subject, String content, String writter) {
	        this.subject = subject;
	        this.content = content;
	        this.writter = writter;
	 }
	public String getWritter() {
		return writter;
	}

	public void setWritter(String writter) {
		this.writter = writter;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "Board [subject=" + subject + ", content=" + content + "]";
	}
}




public class BoardEx {

	public static void main(String[] args) {
		List<Board> list = new ArrayList<Board>();
		list.add(new Board("title1", "content1", "wirtter1"));
		list.add(new Board("title2", "content2", "wirtter2"));
		list.add(new Board("title3", "content3", "wirtter3"));
		list.add(new Board("title4", "content4", "wirtter4"));
		list.add(new Board("title5", "content5", "wirtter5"));
		
		System.out.println("현재 게시된 글의 수 " + list.size());
		
		System.out.println("2번 인덱의 게시글 정보"+list.get(2));
		System.out.println("--------------------");
		System.out.println("게시글 목록");
		System.out.println("--------------------");
		for(int i=0; i<list.size(); i++) {
			System.out.println(i+"번 인덱스의 게시글 정보"+list.get(i));
		}
		list.remove(2);
		list.remove(2);
		System.out.println("--------------------");
		System.out.println("삭제후 게시글 목록");
		System.out.println("--------------------");
		for(int i=0; i<list.size(); i++) {
			System.out.println(i+"번 인덱스의 게시글 정보"+list.get(i));
		}
		
		
	}

}
