package ex0406;

class Box<T>{
	public T content; //Point content;
	
}









public class BoxEx {

	public static void main(String[] args) {
		Box<String> box1 = new Box<String>();
		box1.content ="Hi";
		System.out.println(box1.content);
		
		Box<Integer> box2 = new Box<Integer>();
		box2.content = 100;
		System.out.println(box2.content);
		
		Box<Point> box3 = new Box<Point>();
		box3.content = new Point(2,3);
		System.out.println(box3.content);
		
	}

}
