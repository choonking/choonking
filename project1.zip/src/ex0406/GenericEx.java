package ex0406;

class Product<K, M> { //제네릭 타입 
	
	private K kind;
	private M model; //필드
	
	public K getKind() { return this.kind;}
	public M getModel() { return this.model;}
	public void setKind(K kind) {this.kind = kind;}
	public void setModel(M model) {this.model = model;}
	
	
}

class Tv {
	@Override
	public String toString() {
		
		return "TV";	}
	
}
class Car {
	
}




public class GenericEx {

	public static void main(String[] args) {
		
		Product<Tv, String> p1 = new Product<Tv, String>();
		
		p1.setKind(new Tv());
		p1.setModel("스마트Tv");
		
		System.out.println(p1.getKind());
		System.out.println(p1.getModel());
		
		Product<Integer, String> p2 = new Product<Integer, String>();
		p2.setKind(1);
		p2.setModel("one");
		
		System.out.println(p2.getKind());
		System.out.println(p2.getModel());
		
		
	}

}
