package ex0406;

class SmartPhone { 
	private String company;
	private String os;



	public SmartPhone(String company, String os) {
		this.company = company;
		this.os = os;
	}
	@Override
	public String toString() {

		return company + ", "+os;

	}
}






public class ToStringEx {

	public static void main(String[] args) {
		SmartPhone myPhone = new SmartPhone("삼성전자", "안드로이드");
		
		String strObj = myPhone.toString();
		System.out.println(strObj);
		
		System.out.println(myPhone);

		/*
		 * 위 코드는 toString() 메소드를 사용하여 객체의 정보를 
		 * 출력하는 예제입니다. SmartPhone 클래스에서 toString()
		 * 메소드를 오버라이딩하여, SmartPhone 객체의 정보를 문자열로 
		 * 반환하도록 구현하였습니다.
		 * 
		 * main() 메소드에서 SmartPhone 객체를 생성한 후, 
		 * toString() 메소드를 직접 호출하여 객체의 정보를 문자열로 변환하고
		 * 출력하였습니다. 또한, System.out.println() 메소드를 사용하여 
		 * SmartPhone 객체를 출력하면, 자동으로
		 * toString() 메소드가 호출되어 객체의 정보가 출력됩니다.
		 */
	}

}
