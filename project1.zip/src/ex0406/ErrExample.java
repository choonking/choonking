package ex0406;

public class ErrExample {

	public static void main(String[] args) {
		try {
			int value = Integer.parseInt("1oo");
			
		} catch(NumberFormatException e) {
			System.err.println("[에러 내용]");
			System.err.println(e.getMessage());
		
		}
	}

}
/*
 * 해당 코드는 "1oo"라는 문자열을 정수로 변환하려고 시도하고 있지만, 
 * 숫자가 아닌 문자가 포함되어 있어
 * NumberFormatException이 발생하는 예제이다
 * catch 블록에서는 해당 예외의 메시지를 출력하고 있다. 따라서 이 코드를 실행하면 다음과 같은 결과가 출력될 것
 * [에러 내용] For input string: "1oo"
 * 참고로, "System.err"을 사용하면 표준 오류 출력 스트림으로 출력됨. 일반적으로 "System.out"을 사용하면 표준 출력
 * 스트림으로 출력됨.
 */