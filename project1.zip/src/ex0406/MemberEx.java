package ex0406;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Members{
	private String name;
	private String phoneNo;
	private String addr;

	public Members(String name, String phoneNo, String addr) {
		super();
		this.name = name;
		this.phoneNo = phoneNo;
		this.addr = addr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}

	@Override
	public String toString() {
		return "Members [name=" + name + ", phoneNo=" + phoneNo + ", addr=" + addr + "]";
	}
}



public class MemberEx {


	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int menu = 0;
		List<Members> al= new ArrayList<Members>(); //객체 생성

		BREAK:
			while(true) {
				System.out.println("==============================================================");
				System.out.println("1번 전화번호 추가 2.전화번호 조회 3.전화번호 삭제 4.전화번호 목록 5.프로그램 종료");
				System.out.println("==============================================================");
				System.out.print("메뉴를 선택하세요 >> ");
				menu = scan.nextInt();
				switch(menu) {
				case 1 : //추가 
					System.out.println("이름, 전화번호, 주소 순으로 입력하세요");
					al.add(new Members(scan.next(), scan.next(), scan.next()));
					break;
				case 2 : //조회
					   System.out.println("조회할 회원의 이름을 입력하세요");
	                    String search = scan.next();
	                    boolean found = false;
	                    for(int i=0; i<al.size(); i++) {
	                        Members member = al.get(i);
	                        if(member.getName().equals(search) || member.getPhoneNo().equals(search)) {
	                            System.out.println(member);
	                            found = true;
	                            break;
	                        }
	                    }

	                    if(!found) { 
	                        System.out.println("존재하지 않는 회원입니다.");
	                    }
	                    break;
				case 3 : //삭제
					System.out.println("삭제할 회원의 이름을 입력하세요");
					String deleteName = scan.next();
					boolean deleted = false;
					for(int i=0; i<al.size(); i++) {
						Members member = al.get(i);
						if(member.getName().equals(deleteName)) {
							al.remove(member);
							System.out.println("회원 " + deleteName + "을(를) 삭제하였습니다.");
							deleted = true;
							break;
						}
					}
					if(!deleted) {
						System.out.println("존재하지 않는 회원입니다.");
					}
					break;
				
			case 4 : //목록보기
				System.out.printf("목록에 저장된 회원의 수는 %d명입니다. \n", al.size());
				for(int i=0; i<al.size(); i++) {
					System.out.println(al.get(i));
				}
				break;
			case 5 : //종료 (무한루프 탈출)
				break BREAK;
			}


	}


}

}
