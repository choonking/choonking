package Ex0321;

import java.util.Scanner;

public class OpEx1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int a = scan.nextInt();
		int b = scan.nextInt();
		int sum = a + b;
		int avg = sum / 2;

		System.out.println("sum : " + sum + " avg : " + avg );
		System.out.printf("sum : %d avg : %d", sum, avg );
		
		System.out.println( (3 < 5) && (1 == 1) ); // true && true --> true
		System.out.println( (3 < 5) && (1 == 2) ); // true && false --> false
			
	}

}
