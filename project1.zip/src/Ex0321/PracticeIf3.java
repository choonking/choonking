package Ex0321;

import java.util.Scanner;

public class PracticeIf3 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("몸무게(kg) : ");
		int weight = scan.nextInt();
		System.out.print("신장(m) : ");
		double height = scan.nextDouble();
		
		int bmi = (int)(weight/(height*height)); //double형인 bmi를 int형으로 변환 (bmi = 몸무게 / 키의 제곱) 
		System.out.println("BMI : " + bmi);
		
		if (bmi < 18.5) { 				//bmi가 18.5 미만일때
			System.out.print("저체중");
		} else if (bmi < 25) { 				//bmi가 18.5 이상 25 미만일때
			System.out.print("정상체중");
		} else if (bmi < 30) { 				//bmi가 25 이상 30 미만일때
			System.out.print("1단계 비만");
		} else if (bmi < 40) { 				//bmi가 30 이상 40 미만일때
			System.out.print("2단계 비만");
		} else{ 					//bmi가 40 이상일때
			System.out.print("3단계 비만");
		}
		
		System.out.print("입니다");
		
		
		
	}
}
