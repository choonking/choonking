package Ex0321;

public class OrEx {
	public static void main(String[] args) {
		
		System.out.println( (3 < 5) || (1 == 1) );
		System.out.println( (3 < 5) || (1 == 2) );
		System.out.println( (3 > 5) || (1 == 1) );
		System.out.println( (3 > 5) || (1 == 2) );
		
		
	}
}
