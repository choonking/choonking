package Ex0321;

import java.util.Scanner;

public class Practice3 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("주행 속도(km/h) : " );
		int v = scan.nextInt(); //속도 입력
		System.out.print("주행 시간(h) : ");
		int t = scan.nextInt(); //시간 입력
	
		int s = v * t; // 거리
		
		System.out.println("주행 이동 거리(km) : " + s);
	}
}
