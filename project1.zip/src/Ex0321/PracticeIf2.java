package Ex0321;

import java.util.Scanner;

public class PracticeIf2 {

		public static void main(String[] args) {
			
				Scanner scan = new Scanner(System.in);
				
				System.out.print("인원 수를 입력하시오 -->> ");
				int person = scan.nextInt();
				
				if (person == 1) {
					System.out.println("400,000원 지원");
				} else if (person == 2) {
					System.out.println("600,000원 지원");
				} else if (person == 3) {
					System.out.println("800,000원 지원");
				} else{
					System.out.println("1,000,000원 지원");
				}
				
				
		}
}
