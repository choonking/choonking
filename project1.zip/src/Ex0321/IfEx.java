package Ex0321;

import java.util.Scanner;

public class IfEx {

	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in);
//		
//		System.out.print("점수를 입력하시오->> ");
//		int score = scan.nextInt();
//		
//		if (score >= 80) {
//			System.out.println("축하합니다! 합격입니다.");
//			
//		}
//		else {
//			System.out.println("불합격입니다. 나중에 다시 도전하세요! ");
//		}
//	
		Scanner scan = new Scanner(System.in);
		
		int score = scan.nextInt();
		if (score >= 90) {
			System.out.println("A");
		} else if (score >= 80) {
			System.out.println("B");
		} else if (score >= 70) {
			System.out.println("C");
		} else if (score >= 60) {
			System.out.println("D");
		} else {
			System.out.println("F");
		}

		
	}
	
}