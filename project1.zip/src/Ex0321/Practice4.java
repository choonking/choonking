package Ex0321;

import java.util.Scanner;

public class Practice4 {
	
	public static void main(String[] args) {
		
		int basic;	//기본요금
		double price;	//단가
		double fee;	//전기요금
		
		Scanner scan = new Scanner(System.in);
				
		System.out.print("전기 사용량을 입력하세요 -->> ");
		int use = scan.nextInt(); //사용량 입력
		
		System.out.printf("사용량 : %d.0 kmh\n" , use  );
		
		if (use <= 200) {	//사용량이 200이하 일때
			basic = 910;
			price = 99.3; 
		} else if (use <= 400) {	//사용량이 201~400 일때
			basic = 1600;
			price = 187.9;
		} else {	//나머지
			basic = 7300;
			price = 280.6;
		}
		
		fee = basic + use * price; //전기요금 계산 (기본요금 + 사용량 * 단가)
		
		System.out.println("기본요금 : " + basic + " 원");
		System.out.println("단가 : " + price + " 원");
		System.out.println("전기 요금 : " + fee + " 원");
		
	}

}
