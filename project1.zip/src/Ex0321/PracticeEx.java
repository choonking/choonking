package Ex0321;

import java.util.Scanner;

public class PracticeEx {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.printf("시간을 초단위로 입력하세요 : ");
		int time = scan.nextInt();
		
		int hour = time / 3600; // time을 3600으로 나누어 몫을 초기화(시간)
		int second = time % 3600; // 나머지값을 second에 초기화
		int minute = second / 60; // 그 나머지값을 60으로 나누어 몫을 초기화(분)
		second %= 60;  // 나머지값은 초 이므로 second에 초기화
		
		System.out.printf("%d초는 %d시간 %d분 %d초입니다", time, hour, minute, second);
	}
}
