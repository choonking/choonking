package Ex0321;

import java.util.Scanner;

public class Practice2 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("수심을 입력하세요 : ");
		int depth = scan.nextInt();
		
		depth /= 10; // 수심에 십의 자리를 저장 ( 수심 = 수심 / 10 )
		double temp = 20; // 온도 초기화
		double decr = 0.7; // 감소변수
		
		temp -= depth*decr; // 온도 계산 ( 온도 = 온도 - (수심의 십의 자리 * 감소변수))
		
		System.out.printf("수온 : %.1f ", temp);
		
		
	}

}
