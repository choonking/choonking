package Ex0321;

import java.util.Scanner;

public class PracticeIf {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("기계의 온도를 입력하세요. ");
		double temp = scan.nextDouble();
		
		if (temp >= 40) {
			System.out.println("팬(Fan) 가동");
		} 
		else {
			System.out.println("팬(Fan) 중지");
		}
		
	}
}
