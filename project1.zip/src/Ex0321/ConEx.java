package Ex0321;

public class ConEx {
	
	public static void main(String[] args) {
		
		int num1 = 100;
		num1 = num1 + 200;
		System.out.println(num1);
		num1 = num1 + 300;
		
		num1 += 400; // num1 = num1 + 400;
		
	}
}
