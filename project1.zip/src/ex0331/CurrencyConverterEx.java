package ex0331;

class CurrencyConverter{
	private static double rate; // 한국원화에 대한 환율
	public static double toDollar(double won) {//원화 * 환율 = 달러 환전액
		
		return rate*won;
								//한국 원화를 달러로 변환 
	}
	public static double toKWR(double dollar) {//달러 * 환율 = 원화 환전액 
//		
		return rate*dollar;
	}
	public static void setRate(double r) {
		
		rate = r;
	}
}









public class CurrencyConverterEx {

	public static void main(String[] args) {
		CurrencyConverter. (1292.3won)
	//100만원은 	
	//773.8 달러	
	//1달러에 1292원	
		System.out.printf("백만원은 %.3f달러입니다", );
		System.out.printf("백달러는 %.3f원입니다", );
		
		
		

	}

}
