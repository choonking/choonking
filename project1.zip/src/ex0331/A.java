package ex0331;

public class A {
	int a = 40; //인스턴스 멤버는 객체를 생성 후 레퍼런스로 접근 가능
	void printA() { //static 메소드 안에서는 객체에 접근할수 없음
		System.out.println(a); //static 과 this는 같이 쓸수가 없음 
//		static void printA() {
//			System.out.println(this.a); 
		}
	}

	public static int add(int a, int b) {
		return a+b;
	}
	
	public static void main(String[] args) { 
		A aa = new A();
		System.out.println(aa.a); //static 안에서는 명확히 선언이 있어야함
		aa.printA();
		
	add(1,2);
	}

}
