package ex0331;

public class Phone {
	public String model;
	public String color;
	
	public void bell() {
		System.out.println("벨 울림");
	}
	public void sendVoice(String message) {
		System.out.println("본인 : "+message);
	}
	public void receiveVoice(String message) {
		System.out.println("상대 : "+message);
	}
	public void hangup() {
		System.out.println("전화 끊기 ");
		

}
}