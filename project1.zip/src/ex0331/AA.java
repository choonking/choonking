package ex0331;

public class AA {

	public int p;
	private int n;
	public void setN(int n) {
		this.n=n;
	}
	public int getN() {
		return n;
	}
}
