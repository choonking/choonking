package ex0331;

public class ABEx {

	public static void main(String[] args) {
		AA a = new AA();
		BB b = new BB();
		a.p = 5;
//		a.n = 5;
		a.setN(5);
		b.p = 5;
//		b.n = 5;
		b.setN(5);
		b.setN(10);
		int i=b.getN();
//		b.m = 20;
		b.setM(20);
		System.out.println(b.toString());

	}

}
