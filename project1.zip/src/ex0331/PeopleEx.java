package ex0331;
class People{
	void speak() {
		System.out.println("말하다");
	}
	void eat() {
		System.out.println("먹다");
	}
	void walk() {
		System.out.println("걷다");
	
}
class Student extends People{
	void study() {
		System.out.println("공부하다");
	}
	
}
class StudentWorker extends Student{

void work() {
	System.out.println("일하다");
}

}
class Researcher extends People{
	

void research() {
	System.out.println("연구하다");
}










public class PeopleEx {
	
	public static void main(String[] args) {
		Student s = new Student();
		s.speak();
		s.eat();
		
		Researcher r= new Researcher();
		StudentWorker sw = new StudentWorker();
		sw.eat();
		sw.study();
		sw.work();
	}
}



		

	


