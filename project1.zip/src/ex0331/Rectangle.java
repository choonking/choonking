package ex0331;

class Rectangle {

	
	public static double length=1.0,width=1.0;
	public Rectangle(){}
	public Rectangle(double length, double width) {
			this.length = length; this.width = width;
		}
	public double getLength() { // 현재 length 리턴
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getArea() {
		return width*length;
	}
	public double getPerimeter() {
		return (width+length)*2;	
	}
			
	
	public String toString() {
//		return"Rectangle[length="+length+", width="+width+"]";
		return String.format("Rectangle[length=%.1f, width=%.1f]", length, width);
		
	}
		

public class RectangleEx {		
	//static -> 클래스 파일들, static 키워드 붙은것들 .. 가장 먼저 
	//메모리에 로딩됨 
		public static void main(String[] args) {
			Rectangle r1 = new Rectangle();
//			Rectangle r2 = new Rectangle(3.0, 4.0);
			System.out.printf("%s의 둘레는 %.1f, 면적은 .1f\n"
					,r1.toString(), r1.getPerimeter(), r1.getArea());
//			System.out.printf("%s의 둘레는 %.1f, 면적은 .1f\n"
//					,r2.toString(), r2.getPerimeter(), r2.getArea());
		}
	}

}
