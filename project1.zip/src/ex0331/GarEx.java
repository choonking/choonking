package ex0331;
class Person {
	static String name; //스태틱 멤버(고정 멤버,클래스멤버) 딱 한개만 만들어서 객체마다 공유
	//객체를 생성하지 않아도 사용할 수 있음 
	int age; //인스턴스 멤버, 객체마다 만들어서 따로 공유하지 않음
	Person(){}
	Person(String name){
		this.name = name;
		
	}
	String getName() {
		return this.name;
	}
}





public class GarEx {

	public static void main(String[] args) {
//		String str = "Hello"; //garbage 
//		str = "Java";
		Person a,b;
		
		
		
		a = new Person("conan");
//		System.out.println("a가 참조하는 객체의 이름 " + a.name);
		b = new Person("rose");
//		a.age = 10;
//		b.age = 17;	
		System.out.println("a가 참조하는 객체의 이름 " + a.name);
		
		
		Person.name = "kid";
		System.out.println("클래스 멤버의 이름은 " + Person.name);
		System.out.println("a가 참조하는 객체의 이름 " + a.name);
		
//		System.out.println("a가 참조하는 객체의 나이 " + a.age);
//		System.out.println("b가 참조하는 객체의 이름 " + b.name);
//		System.out.println("b가 참조하는 객체의 이름 " + b.age);
		
		System.out.println(Math.abs(1));
		System.out.println(Math.abs(-1));
		
	}

}
