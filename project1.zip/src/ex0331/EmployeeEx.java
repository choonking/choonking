package ex0331;

import java.util.Scanner;

class Employee {
	private int id;
	private String name;
	private int salary;
	
	public Employee(int id, String name, int salary) { //매개변수 생성자만 
		this.id = id;	this.name = name;	this.salary = salary;
	}
	
	public int getId() { //
		return this.id;
	}
	public String getName() {
		return this.name;
	}
	public int getSalary() {
		return this.salary;
	}
	public void setSalary(int salary) {
		this.salary = salary; 
	}
	public int getAnnualSalary() {
		return salary*12;
	}
	public int raiseSalary(int percent) {
		
		return salary *percent/100; //일단 ㅇㅋ 
				
		
	}
	public String toString() {
		return String.format("Employee[id=%d, name=%s, salary=%d", id, name, salary);
		
	}
	
	
}


public class EmployeeEx {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Employee[] eArray = new Employee[3]; //배열 객체 생성
		for (int i=0; i<eArray.length; i++)	{
			eArray[i] = new Employee(scan.nextInt(),scan.next(),scan.nextInt());
		}
		for(int i=0; i<eArray.length; i++) {
			System.out.printf("%s의 연봉은 %d 월급 인상분은 %d\n"
					, eArray[i].toString()
					, eArray[i].getAnnualSalary()
					, eArray[i].raiseSalary(i+1)*10);
		}
	
			
	}

}
