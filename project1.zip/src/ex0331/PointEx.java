package ex0331;

class Point{// 부모
	 
	int x, y; //default, 같은 패키지안에서 접근 가능 
	void set(int x, int y) {
		this.x=x; this.y=y;
	}
	void showPoint() {
		System.out.printf("(%d, %d)\n", x, y);
	}
}
class ColorPoint extends Point{ //자식
	String color; //null 
	void setX(int x) {
		this.x=x;
	}
	void setColor(String color) {
		this.color = color;
		
	
	}
	void showColorPoint() { 
		//System.out.printf("%s(%d, %d)\n",color, x, y);
		System.out.printf("%s",color);
		showPoint();
	}
}





public class PointEx {

	public static void main(String[] args) {
		ColorPoint p = new ColorPoint();
		p.set(3, 4); p.setColor("red"); p.showPoint();
		p.showColorPoint();

	}

}
