package ex0331;

public class BB extends AA{ //클래스 AA를 상속받은 클래스 BB임 
	private int m;
	public void setM(int m) {
		this.m = m;
	}
	public int getM() {
		return m;
	}
	public String toString() {
		String s = getN()+" "+getM();
		return s;
	}

}
