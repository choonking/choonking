package ex0331;

class Circle{
	int radius; String color;
	static int numberOfCircles;
	Circle(int radius, String color){
		this.radius = radius; this.color = color;
		
	}
}






public class CircleEx {

	public static void main(String[] args) {
		Circle c1 = new Circle(100, "red"); //c1.numberOfCircles = 0
		Circle c2 = new Circle(50, "yellow"); //c2.numberOfCircles = 0
		Circle.numberOfCircles++; //c1이 참조하는 객체의 원의 개수 1증가
		System.out.println(Circle.numberOfCircles);
		Circle.numberOfCircles++; //c2가 참조하는 객체의 원의 개수 1증가
		Circle.numberOfCircles++; //c2가 참조하는 객체의 원의 개수 1증가
		System.out.println(Circle.numberOfCircles);
		
		

	}

}
