package ex0331;
//Account, ModifierEx는 동일한 패키지 안에 있음
class Account{ //default 접근제한자 -> 동일한 패키지 안에있는 경우 ,다른 클래스에서 접근 가능
//	public int balance//같은 패키지, 또는 다른 패키지든 같은 클래스든 다른 클래스든 쓸수 있음 
//	int balance; //디폴트 -> package-friendly ->같은 패키지 안에있는 경우=, 접근 가능 
	private int balance; // 자기(Account) 클래스 외부에서는 접근 불가
	private boolean flag;
	
	
	public boolean isFlag() { //boolean getter 
		return flag;
	}
	public int getBalance() { //get 현재 필드값을 읽어옴
		return balance;
	}
	public void setBalance(int balance) { //set 새로 값을 입력함 
		this.balance = balance;
	}
	
}

public class ModifierEx { //public 접근제한자

	public static void main(String[] args) {
		Account acc = new Account(); 
//		acc.balance = 1000;
		acc.setBalance(1000);
		System.out.println("현재 잔액은 " +acc.getBalance());

	}

}
