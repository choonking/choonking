package package2;

import package1.A;
import package1.B;

public class C {
//	A a1 = new A(true); //o
//	A a2 = new A(1); 
//	A a3 = new A("String");
	public void method() {
	A a = new A();
	a.field1 = 1;
	a.field2 = 1; //default 같은패키지에서만
	a.field3 = 1; //private A클래스내에서만
	a.method1();
	a.method2(); //default
	a.method3(); //private
	}


}
