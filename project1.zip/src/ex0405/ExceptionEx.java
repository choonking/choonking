package ex0405;




public class ExceptionEx {

	public static void main(String[] args) {

		String str = null;
		System.out.println("문자열의 길이 : "+ str.length());

		try {
			System.out.println(Integer.parseInt(str)+1);
			System.out.println("Hello");
		}catch(Exception e) {
			System.out.println(e.toString());
			System.out.println("정수로 바꿀 수 없는 문자열임");
		}



		//		int iArray[]= new int[2]; //0,1
		//		try {
		//			iArray[0] = 2;
		//			System.out.println(iArray[0]);
		//			}catch(ArrayIndexOutOfBoundsException e) {
		//				System.out.println("인덱스가 배열 크기의 범위를 벗어남");
		//				
		//			}

		//		try{
		//			System.out.println(4/0);
		//		}catch(ArithmeticException e) {
		//			System.out.println("예외의 원인 :"+e.getMessage());
		//			System.out.println("0으로 나누어서 예외 발생 가능성 있음");
		//			e.printStackTrace();
		//		}

	}

}
