package ex0405;

class Point{
	int x, y;
	public Point(int x, int y) {
		this.x =x ; this.y = y;
	}

		


}





public class ObjectProperty {

	public static void main(String[] args) {
		Point p = new Point(2,3); 
	    System.out.println(p.getClass().getName()); 
	    //getClass() -> 현재 객체의 class 반환, Object 꺼
	    //getName() -> 이름 반환, class 꺼 
	    //메소드 체이닝 ->체인 라이트닝 같은느낌 연쇄적
	    System.out.println(p.hashCode()); //숫자가 틀림 
	    System.out.println(p.toString());
	    System.out.println(p);
	    
	    String str = "Hello";
	    System.out.println(str.toString());
	}

}
