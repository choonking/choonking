package ex0405;

interface InterfaceA{
	void methodA();
}

interface InterfaceB{
	void methodB();
}

interface InterfaceC extends InterfaceA, InterfaceB {
	void methodC();
}

class InterfaceCImpl implements InterfaceC{
	@Override
	public void methodA() {
		System.out.println("InterfaceCImpl-methodA() 실행");
		
	}
	@Override
	public void methodB() {
		System.out.println("InterfaceCImpl-methodB() 실행");

		
	}
	@Override
	public void methodC() {
		System.out.println("InterfaceCImpl-methodC() 실행");
	}
	
}





public class ExtendsEx {

	public static void main(String[] args) {
		InterfaceCImpl impl = new InterfaceCImpl();
		
		InterfaceA ia = impl;
		ia.methodA();
//		ia.methodB();
		System.out.println();
		
		InterfaceB ib = impl;
//		ib.methodA();
		ib.methodB();
		System.out.println();
		
		InterfaceC ic = impl;
		ic.methodA();
		ic.methodB();
		ic.methodC();	
		
	}

}
