package ex0405;

import java.util.Scanner;

public class ThrowsEx { //예외 떠넘기기
	

	public static void main(String[] args) throws NumberFormatException {
		Scanner scan = new Scanner(System.in);
		try {
		square(scan.next());
		}
		catch(Exception e) {
			System.out.println("정수로 바뀔 수 없음");
		}
	}

	public static void square(String next) throws NumberFormatException{
		
		int n = Integer.parseInt(next);
		System.out.println(n*n);
	
		
	}

}
