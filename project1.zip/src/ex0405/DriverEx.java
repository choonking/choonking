package ex0405;

class Driver {
	void drive (Vehicle vehicle) {
		vehicle.run();
	}
}

class Buss implements Vehicle {
	@Override
	public void run() {
		System.out.println("버스가 달립니다.");
	}
}

class Taxi implements Vehicle { 
	@Override
	public void run() {
		System.out.println("택시가 달립니다.");
		
	}
}




public class DriverEx {

	public static void main(String[] args) {
		Driver driver = new Driver();
		
		Buss bus = new Buss();
		Taxi taxi = new Taxi();
		
		driver.drive(bus);
		driver.drive(taxi);

	}

}
