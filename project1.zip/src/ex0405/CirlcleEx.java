package ex0405;

interface GeomericObject {
	public double getParimeter();
	public double getArea();

}
interface Resizable {
	public void resize(int percent);
}

class Circle implements GeomericObject {

	double radius = 1.0;

	public Circle(double radius){
		this.radius = radius;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;	
	}

	@Override
	public double getParimeter() {
		return radius*2*Math.PI;
	}
	@Override
	public double getArea() {
		return radius*radius*Math.PI;
	}

	public String toString() {		
		return String.format("Circle[radius=%.1f]", radius);
	}
}

class ResizableCircle extends Circle implements Resizable { //extends가 먼저 imple란트가 다음 
	
	
	public ResizableCircle(double radius) {	
		super(radius); 
	}
	
	@Override
	public void resize(int percent) {
		radius = radius+radius*percent/100;//percent*0.01; 
		
		
	}
	public String toString() {	
		return String.format("ResizeableCircle[%s]" , super.toString());
	}
	
}





public class CirlcleEx {

	public static void main(String[] args) {
		Circle c = new Circle(2.0);
		ResizableCircle d = new ResizableCircle(3.0);
		System.out.printf("%s의 둘레는 %.1f, 면적은 %.1f\n",c, c.getParimeter(),c.getArea());
		System.out.printf("----------------------------------------------\n");
		System.out.printf("%s의 둘레는 %.1f, 면적은 %.1f\n",d, d.getParimeter(),d.getArea());
		System.out.printf("----------------------------------------------\n");
		d.resize(10);
		System.out.printf("%s의 둘레는 %.1f, 면적은 %.1f\n", d , d.getParimeter(),d.getArea());

	}


}
