package ex0405;

interface Vehicle{
	void run();
	
}

class Bus implements Vehicle{
	@Override
	public void run() {
		System.out.println("버스가 달린다");
		
	}
	public void checkFare() {
		System.out.println("승차 요금 확인");
	}
}








public class CastingExample {

	public static void main(String[] args) {
		Vehicle vehicle = new Bus();
		vehicle.run();
		//vehicle.checkFare();
		
		Bus bus = (Bus) vehicle;
		bus.checkFare();

	}

}
