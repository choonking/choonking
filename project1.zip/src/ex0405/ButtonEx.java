package ex0405;

interface MyButton{
	void click();
}
class CallButton implements MyButton{

	@Override
	public void click() {
		System.out.println("통화버튼이 눌렸음");

	}

}
class StopButton implements MyButton{

	@Override
	public void click() {
			System.out.println("종료버튼이 눌렸음");
		}

	}



public class ButtonEx {

	public static void main(String[] args) {
		MyButton callBtn = new MyButton() {
			@Override
			public void click() {
				System.out.println("통화버튼이 눌렸음");
				
			}
		}; //<--세미콜론 중요 
		MyButton stopBtn = new MyButton() {
			@Override
			public void click() {
				System.out.println("종료버튼이 눌렸음");
				
			}
		};
		stopBtn.click();
	}

}
