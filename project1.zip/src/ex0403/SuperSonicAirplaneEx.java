package ex0403;

class Airplane{
	public void land() {
		System.out.println("착륙합니다.");
	}
	public void fly()	{
		System.out.println("일반 비행합니다.");
	}
	public void takeOff()	{
		System.out.println("이륙합니다.");
	}
}
class SupersonicAirplane extends Airplane {
	
	public static final int NORMAL = 1;
	public static final int SUPERSONIC = 2;
	public int flymode = NORMAL;
	

	
	@Override //annotation
	
	public void fly() {
		if(flymode == SUPERSONIC) {
			System.out.println("초음속 비행합니다.");
		} else {
//			Airplane 객체의 fly
			super.fly();
		}
	}


public class SuperSonicAirplaneEx {
	public static void main(String[] args) {
		SupersonicAirplane sa = new SupersonicAirplane();
		sa.takeOff();
		sa.fly();
		sa.flymode =SupersonicAirplane.SUPERSONIC;
		sa.fly();
		sa.flymode =SupersonicAirplane.NORMAL;
		sa.fly();
		sa.land();
	}
	
}
}

	



