package ex0403;

public class ClassName {
	
	int field1; //인스턴스
	void method1() { //인스턴스
		System.out.println("instance method1");
	}
	static int field2; //정적
	static void method2() {
		System.out.println("static method2");
		
	}
	static void method3 () { //static
		ClassName c =new ClassName();
		c.field1 = 10;
		c.method1();
		field2=10;
		method2();
	}
}
