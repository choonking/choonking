package ex0403;

class Doctor{
	public void job() {
		System.out.println("진단과 치료를 한다.");
		
	}
	
	
}

class Surgeon extends Doctor{
	
	public void dojob() {
		super.job();		
	}
	public void job() { //메소드 오버라이딩 , 재정의
		System.out.println("수술을 한다");
	}
	public void job(String str) { //메소드 오버로딩 , 중복정의
		System.out.println(str+ "수술을 한다");
	}
}





public class DoctorEx {

	public static void main(String[] args) {
		Surgeon s = new Surgeon();
		s.dojob();
//		s.job2();
		

	}

}
