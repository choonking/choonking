package ex0403;

class Person {
	private String name;
	private String addr;
		
	public Person(String name, String addr){
		this.name = name; this.addr = addr;
	}
	public String getName() {
		return name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String toString() {
		return String.format("Person [name=%s, address=%s]", name, addr);	
	}
	
}

class Student extends Person {
	private String program;	
	private int year;
	private double fee;
	
	public Student(String name, String addr, String program, int year, double fee) {
	 super(name, addr);
	 this.program=program;
	 this.year=year;
	 this.fee=fee;
	 }

	
	public String getprogram() {
		return this.program;
	}
	public void setprogram(String program) {
		this.program = program;
	}
	public int getyear() {
		return this.year;
	}
	public void setyear(int year) {
		this.year = year;
	}
	public double getfee() {
		return this.fee;
	}
	public void setfee(double fee) {
		this.fee = fee;
	}
	public String toString() {
		return String.format("Student [name=%s, address=%s, program=%s, year=%d fee=%.1f]" 
				,super.toString(), program, year, fee);
		
	}
}
class Staff extends Person {
	private String school;
	private double pay;
	public Staff(String name, String addr, String school, double pay) {
		super (name, addr);
		this.school=school;
		this.pay=pay;
	}
	
	public String getSchool() {
			return this.school;
		}
	public void setSchool(double fee) {
			this.school = school;
		}
	public double getpay() {
		return this.pay;
	}
public void setfee(double pay) {
		this.pay = pay;
		
	}
public String toString() {
	return String.format("Staff [name=%s, address=%s],school=%s,pay=%.1f]" 
			,super.toString(), school, pay);
	
}
	
		


public class PersonEx {

	public static void main(String[] args) {
	
Person p = new Person("코난", "미란이네");
System.out.println(p.toString());
p.setAddr("주소 불상");System.out.println(p.toString());
Student st1 = new Student("장미", "브라운박사님댁", "생명과학", 1, 25000.0 );
//System.out.println(st1.toString);
Student st2 = new Student("미란", "미란이네", "태권도", 3, 3000.0 );
//System.out.print(st2.toString);
Staff s = new Staff("유명한", "미란이네", "청솔대학", 20.0 );
//System.out.print(s.toString);

	}
}
}

