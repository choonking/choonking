package ex0403;

class Account{
	private String id;
	private String name;
	private int balance=0;
	public Account() {
		this(null, null, 0); //비워놔도 상관없음 
	}
	public Account(String id, String name) {
		this(id,name, 0) ; //자기 클래스안에서 다른 생성자 호출 하는 역할 
	}
	public Account(String id, String name, int balance) { //모든 필드를 초기화 하는 생성자
		this.id = id; this.name=name; this.balance=balance;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;	
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;	
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {  //모든 필드에 대한 getter setter 
		this.balance = balance;	 //잔액
	}
	public String toString() {
		return String.format("Account[id=%s, name=%s, balance=%d]", id, name, balance); //toString 
	}


	public int deposit(int amount) { //입금 기능
		balance+=amount;
		return balance;
	}
	public int withdraw(int amount) { //출금 기능
		if(amount<=balance) { //출금이 가능한 경우 
			return balance=balance-amount;
		}
		else { //출금 불가능 한경우
			System.out.print("출금액이 잔액초과\n"); 
			return balance;
		}
	}

	public int transferTo(Account another, int amount) { //송금 기능
		if(amount<=balance) { //송금 가능
			balance = balance -amount;
			another.balance= balance+amount;
		}
		else {
			System.out.print("송금액이 잔액초과!!\n");			
		}
		return balance;
	}
}




public class AccountEx {

	public static void main(String[] args) {


		System.out.println("초기 계좌 정보");

		Account[] iArray = new Account[3]; //배열 객체 생성
		iArray[0] = new Account(); //코난
		iArray[0].setId("11-111-111");
		iArray[0].setName("명박");
		iArray[0].setBalance(20000);
		iArray[1] = new Account("22-222-222", "근혜"); //
		iArray[1].setBalance(100000);
		iArray[2] = new Account("33-333-333", "석열", 50000); //




		for(int i=0; i<iArray.length; i++) {
			System.out.println(iArray[i].toString());
		}

		System.out.println("---------------------------------------------");
		System.out.println("명박님이 근혜님에게 30000원 송금 시도");
		iArray[0].transferTo(iArray[1], 30000);

		System.out.println("명박님이 50000원을 입금하였음");
		iArray[0].deposit(50000);

		System.out.println("명박님이 근혜님에게 30000원 송금하였음");
		iArray[0].transferTo(iArray[1], 30000);

		System.out.println("석열님이 4500원을 출금 하였음");
		iArray[2].withdraw(4500);
		System.out.println("---------------------------------------------");
		System.out.println("은행 업무 이후 계좌 정보");
		for (int i=0; i<iArray.length; i++) {
			System.out.println(iArray[i].toString());
		} //근혜 계좌가 이상함 
	}




}


