package ex0403;

import java.util.Scanner;

class Customer {


	private int id; 
	private String name;
	private int discount;

	public Customer(int id, String name, int discount) {
		this.id = id; this.name = name; this.discount = discount;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public String toString() {
		return String.format("%s(%d)", name , id);
	}


}
	class Invoice{
		private int id;
		private Customer customer;
		private double amount;


		public Invoice(int id, Customer customer, double amount) {
			this.id= id;
			this.customer = customer;
			this.amount= amount;

		}
		public int getId() {
			return id;
		}

		public Customer getCustomer(){
			return customer;

		}
		public void setCustomer(Customer customer) {
			this.customer = customer;
		}
		public double getAmount(){
			return amount;

		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		public String getCustomerName(){
			return customer.getName();

		}
		public double getAmountAfterDiscount() { //amount총액 에서 할인을 적용한 총액
			return amount*(1-customer.getDiscount()/100.);  //amount * 1-(10/100) 
		}

	}
	public class CustomerEx {


		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);

			Invoice[] iArray = new Invoice[3]; //이렇게 하셈 
			for(int i=0; i<iArray.length; i++) {

				System.out.println("상품아이디, 고객명, 할인율,총액 순서대로 입력하세요 >>");
				iArray[i] = new Invoice(
						scan.nextInt()
						, new Customer(i+1,scan.next(),scan.nextInt())
						, scan.nextDouble());
			}


			for(int i=0; i<iArray.length; i++) {
				System.out.printf("%s님께서 %d를 구매하고 총액 %.1f원에서 %d%% 할인 받아 최종 지불액은 %.1f원임\n"
						,iArray[i].getCustomer().toString()
						,iArray[i].getId() 
						,iArray[i].getAmount()
						,iArray[i].getCustomer().getDiscount()
						,iArray[i].getAmountAfterDiscount());

			}
		}
	}



