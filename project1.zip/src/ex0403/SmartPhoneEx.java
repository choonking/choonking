package ex0403;

class Phone { //부모 
	
	public String model;
	public String color;
		
	public Phone() {
	
	}
	public Phone(String model, String color) {
		this.model = model; this.color = color;
		System.out.println("SmartPhone(String model, String color) 생성자 실행");
	}
}

class SmartPhone extends Phone { //자식 
	public SmartPhone(String model, String color) { //매개변수 생성자
	//super();
		this.model = model;
		this.color = color;
		System.out.println("SmartPhone(String model, String color) 생성자 실행됨");
	}
}





public class SmartPhoneEx {

	public static void main(String[] args) {
		SmartPhone myPhone = new SmartPhone("갤럭시", "은색");
		
		System.out.println("모델: " + myPhone.model);
		System.out.println("모델: " + myPhone.color);	
		}
		
	}