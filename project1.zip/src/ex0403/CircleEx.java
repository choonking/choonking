package ex0403;


class Circle{
	private int radius;

	public Circle(int radius) {
		radius=0;
	}
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	public String toString() {
		return String.format("Circle[radius=%d]", radius);
	}


}



class ColoredCircle extends Circle{
	private String color;

	public ColoredCircle(int radius, String color) {
		super(radius);  this.color=color;
	}
	public String getColor() {
		return color;
	}
	public void setColor() {
		this.color = color;
	}
	public String toString() {
		return String.format("ColoredCircle[%s,color=%s]", super.toString(), color);
	}
}












public class CircleEx {

	public static void main(String[] args) {

		Circle c = new Circle(2);
		ColoredCircle b = new ColoredCircle(2, "red");
		System.out.println(c.toString());
		System.out.println(b.toString());

	}
}


