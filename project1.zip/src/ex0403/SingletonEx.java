package ex0403;

class Singleton {
	private static Singleton singLeton  = new Singleton();
	
	private Singleton() {} //기본 생성자, 클래스 외부에서 접근 불가 
	static Singleton getInstance(){
		return singLeton;
	}
}






public class SingletonEx {

	public static void main(String[] args) {
//		Singleton obj1 = new Singleton();	 //not visible
//		Singleton obj2 = new Singleton();	 //
		Singleton obj1= Singleton.getInstance();
		Singleton obj2= Singleton.getInstance();
		System.out.println(obj1==obj2);
	}

}
