package ex0403;


class Korean{
	final String nation = "KOR"; //final은 한번 저장하고 끝임
	final String ssn;
	String name;
	
	public Korean(String ssn, String name) {
		this.ssn = ssn; this.name = name;
	}
}

public class KoreanExample {

	public static void main(String[] args) {
		Korean k1 = new Korean("1111-1111" , "허경영");
		System.out.println(k1.nation);
		System.out.println(k1.ssn);
		System.out.println(k1.name);
		
		//k1.nation="US";
		//ㄴk1.ssn = "2222-2222";
		k1.name="트럼프";
		
		System.out.println(k1.nation);
		System.out.println(k1.ssn);
		System.out.println(k1.name);

	}

}
