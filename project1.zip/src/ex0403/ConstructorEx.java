package ex0403;

class A{
	public A() {
	 System.out.println("A 객체 생성");
	}
	public A(int x) {
		System.out.println("매개변수 생성자A");
	}
}

class B extends A{
	public B() {  //A 생성자를 호출 
		System.out.println("B 객체 생성");
	}
	public B(int y) { 
		super(y); //매개변수가 있는 부모 생성자를 호출하는 방법
		System.out.println("매개변수 생성자B");
	}
}




public class ConstructorEx {

	public static void main(String[] args) {
		
		B b =  new B(3);

	}
}




