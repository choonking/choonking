/**
 * 
 */
/**
 * @author manic-063g
 *
 */
module project1 {
}