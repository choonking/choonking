package Ex0323;

import java.util.Scanner;

public class praFor11 {

	public static void main(String[] args) {
		//100 이하의 자연수 n을 입력받고 n개의 정수를 입력받아 평균을 출력하는 프로그램을 작성하시오.

		//(평균은 반올림하여 소수 둘째자리까지 출력하도록 한다.)
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		int b = scan.nextInt();
		int num, sum = 0;
		double avg = 0.0;
		if {
		
		for(int i=0; i<a; i++)	{ //0 으로 시작해서 , 계속 i가 a보다 작을때까지만 1씩 증가하게 반복함
			
			num=scan.nextInt();
			sum+=sum;
		}
		avg = sum/(double)a;
		 {System.out.printf("%3.2f\n", avg);}
		}
	}

}
