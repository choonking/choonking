package Ex0323;

import java.util.Scanner;

public class PracFor02 {

	public static void main(String[] args) {
		//10부터 20까지의 숫자를 차례대로 출력하는 프로그램을 작성하시오.for문을 사용하세요.
		Scanner scan = new Scanner(System.in);
		
		for(int i=10; i<=20; i++) {
			System.out.printf("%d ",i);
		}
		
		

	}

}
