package Ex0323;

import java.util.Scanner;

public class forEx {

	public static void main(String[] args) {
		//0에서 100을 출력하시오.
		//		System.out.println(0);
		//		System.out.println(1);
		//어떤 작업을 반복할 것인가?

		//	 for(int i=0; i<=10; i++) {
		//		 System.out.println(i); //0에서 시작해서 1증가하는 변수를 넣어보자
		//	 }
		Scanner scan = new Scanner(System.in);
		//		int sum=0; 
		//		int num=scan.nextInt();
		//		//1-10까지의 합을 구해서 저장
		//		//덧셈 실행시 새로운 값으로 업데이트 될것
		//	for(int i=1; i<=num; i++) {
				
		//	  sum =	sum+i; //1씩 증가하는 수 i와 이전에 저장된 sum의 값을 읽어와서 			   
		//	  System.out.println("sum : "+ sum);	//다시 sum에 저장
		//	  				//10회 반복
		//	}
		//	System.out.printf("1부터 %d까지의 합은 %d\n",num, sum);

		}

}


