package Ex0323;

import java.util.Scanner;

public class PraFor10 {

	public static void main(String[] args) {
		// 100 이하의 두 개의 정수를 입력받아 작은 수부터 큰 수까지
		// 차례대로 출력하는 프로그램을 작성하시오.
		//입 10 5
		//출 5 6 7 8 9 10
		
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		for(int i=1; i<=100; i++)	{
			for(int j=1; j<=100; j++)
			System.out.print(i+" ");
		}
		
	}

}
