package Ex0323;

public class PraFor03 {

	public static void main(String[] args) {
		// 1부터 20까지의 홀수를 차례대로 출력하는 프로그램을 작성하시오. ​
		
		for(int i=1; i<21;i=i+2) {
			System.out.printf("%d ",i); //i : 1부터 2씩 증가한 결과 출력
			
			//i=i+2;
		}
		

	}

}
