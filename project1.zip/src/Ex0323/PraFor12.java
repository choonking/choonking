package Ex0323;

import java.util.Scanner;

public class PraFor12 {

	public static void main(String[] args) {
		// 10개의 정수를 입력받아 입력받은 수들 중
		// 짝수의 개수와 홀수의 개수를 각각 구하여 출력하는 프로그램을 작성하시오.
//		even : 6
//		odd : 4
		Scanner scan = new Scanner(System.in);
		int num1 = 0;
		int num2 = 0;
		for(int b=1; b<=10; b++)	{
			int c=scan.nextInt();
				if(c%2==0)	{
					num1+=1;
				}
				else num2+=1;
		}
		
		System.out.printf("even : %d\n", num1);
		System.out.printf("odd : %d\n", num2);
	}

}
