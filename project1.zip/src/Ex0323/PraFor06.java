package Ex0323;

import java.util.Scanner;

public class PraFor06 {

	public static void main(String[] args) {
		//5명의 성적을 입력받아서 총점과 평균을 출력하는 프로그램을 작성하시오.
		//(평균은 반올림하여 소수 첫째자리까지 출력한다.)
		//입력 90 85 100 66 88
		//출력 총점 : 429
		//    평균 : 85.8
		Scanner scan = new Scanner(System.in);	
		int score = 0; 
		int sum=0;
		
		for(int i=1; i<=5; i++) {
			//성적 읽어오기
			score=scan.nextInt();
			sum+=score;
//			System.out.printf("score : %d, sum : %d\n", score, sum);
			
			
		}
		System.out.printf("총점 : %d\n", sum);
		System.out.printf("평균 : %3.1f", sum/5.0); //%3.1f 는 음 소수점이라서 5.0은 한쪽은 double이어야 저절로 바뀌니까? 
	}
}
