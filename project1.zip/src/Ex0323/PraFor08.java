package Ex0323;

public class PraFor08 {

	public static void main(String[] args) {
	//	아래 출력예와 같이 출력하는 프로그램을 작성하시오.

//		1 1 1 1 1
//		2 2 2 2 2
//		3 3 3 3 3
//		4 4 4 4 4
//		5 5 5 5 5

//		1 2 3 4 5
//		1 2 3 4 5
//		1 2 3 4 5
//		1 2 3 4 5
//		1 2 3 4 5

//		for(int i=1; i<=5; i++) {		
//			for(int j=1; j<=5; j++) {
//				System.out.print(i+" ");
//			}
//			System.out.println();
//		}
//		
//		
//		for(int i=1; i<=5; i++) {
//			for(int j=1; j<=5; j++) {
//				System.out.print(j+" ");
//			}
//			System.out.println();
//			}
//		}
//}
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=5; j++)	{
				System.out.print(i+" ");
			}
			System.out.println();
		}

	}
}
