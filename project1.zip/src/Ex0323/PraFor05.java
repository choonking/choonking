package Ex0323;

import java.util.Scanner;

public class PraFor05 {

	public static void main(String[] args) {
		// 10개의 정수를 입력받아 그 수들 중 짝수의 개수가 몇 개인지 출력하는 프로그램을 작성하시오.

		// 입력 15 22 3 129 66 81 35 1 46 888
		// 출력 입력받은 짝수는 4개입니다.

		Scanner scan = new Scanner(System.in);
		int a=0;
		for(int b=1; b<=10; b++) { 
			int c=scan.nextInt();
			if	(c%2==0)	{
				a+=1;
			}
		}			

		System.out.printf("입력받은 짝수는 %d개입니다.", a);

	}


}
