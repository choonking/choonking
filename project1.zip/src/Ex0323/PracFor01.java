package Ex0323;

import java.util.Scanner;

public class PracFor01 {

	public static void main(String[] args) {
		// 10 이하의 정수를 입력받아 입력받은 정수만큼 "C언어 프로그래밍"이라고 출력하는 프로그램을 작성하시오. 
		
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		for(int i=1; i<=num;i++)
		{System.out.println("C언어 프로그래밍");
		
		}
	}

}
