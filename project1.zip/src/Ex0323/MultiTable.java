package Ex0323;

import java.util.Scanner;

public class MultiTable {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int dan = scan.nextInt();
		for(int i=1; i<10; i++){

//		System.out.println(dan+"*"+ i +"="
//				+dan*i);
		System.out.printf("%d*%d=%d\n", dan, i, dan*i);
		}

	}

}
