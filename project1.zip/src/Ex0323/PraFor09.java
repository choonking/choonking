package Ex0323;

public class PraFor09 {

	public static void main(String[] args) {
		int dan = 2;
		for(int i=1; i<10; i++){
			for(int j=2; j<10; j++) {
				System.out.printf("%2d * %2d = %2d ", j, i, j*i); //한단씩 출력  *%2d 오른쪽출력
			
			}
			System.out.println();  //한단 출력 마치고 줄바꿈 (for문 밖에 씀)
		}
	}
}
