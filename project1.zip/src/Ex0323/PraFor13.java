package Ex0323;

import java.util.Scanner;

public class PraFor13 {

	public static void main(String[] args) {
		//행과 열의 수를 입력받아 다음과 같이 출력하는 프로그램을 작성하시오.
//입 	3 4
//출 	1 2 3 4 1*1 1*2... 1*4
//		2 4 6 8 2*1 2*2  ... 2*4
//		3 6 9 12 3*1 ...3*4
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		int b = scan.nextInt();
		
		for(int i=1; i<=a; i++) {
			for(int j=1; j<=b; j++)	{
				System.out.print(i*j+" ");
				
			}
			System.out.println();
		}
	}

}
