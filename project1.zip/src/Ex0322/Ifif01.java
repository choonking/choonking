package Ex0322;

import java.util.Scanner;

public class Ifif01 {

	public static void main(String[] args) {
		// 성별에 따라서 남성 성인
		// 남성 미성년자
		// 여성 성인
		// 여성 미성년
		// 여성인 경우: f, 남성인 경우: m
		// 성인 기준은 나이를 20세로
		Scanner scan = new Scanner(System.in);
		System.out.print("성별을 입력하세요 >> ");
		String gen = scan.next(); //문자열로 읽어 첫글자만 가져옴
		char gender = gen.charAt(0);
		System.out.print("나이를 입력하세요 >> ");
		int age = scan.nextInt();
		
		if(gender=='f') { //여성인 경우
			if(age>=20) {
				System.out.println("여성 성인");
			}
			else {
				System.out.println("여성 미성년");
			}
	}
		else {  // if(gender =='m')  중괄호 잘닫아주자 
				if(age>=20) {
					System.out.println("남성 성인");}
				else {
						System.out.println("남성 미성년");
					}
				}
			}
		}
