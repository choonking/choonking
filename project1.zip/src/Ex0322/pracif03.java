package Ex0322;

import java.util.Scanner;

public class pracif03 {

	public static void main(String[] args) {

		 Scanner scan = new Scanner(System.in);
//		1번은 개, 2번은 고양이, 3번은 병아리로 정하고 번호를 입력하면 
//		번호에 해당하는 동물을 영어로 출력하는 프로그램을 작성하시오.
//		해당 번호가 없으면 "I don't know."라고 출력한다.
//		개-dog
//		고양이-cat
//		병아리-chick​ 
		 System.out.print("Number? ");
		 int a = scan.nextInt();
		 
		 if(a==1) {
			 System.out.print("dog");
		 }
		 else if(a==2) {
			 System.out.print("cat");
		 }
		 else if(a==3) {
			 System.out.print("chick");
		 }
		 else {
			 System.out.print("I don't know.");
		 }
		 
		 
		
//입력 Number? 2

	}

}
