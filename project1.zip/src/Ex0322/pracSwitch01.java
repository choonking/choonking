package Ex0322;

import java.util.Scanner;

public class pracSwitch01 {

	public static void main(String[] args) {
		// 정수를 홀수인지 짝수인지 판별하여 홀수임, 짝수임 출력하는 프로그램 작성
		// switch case 사용하기
		Scanner scan = new Scanner(System.in);
		System.out.print("숫자를 입력하세요 >> ");
		int num = scan.nextInt();
		switch(num%2) { //2로 나눈 나머지
		case 0: //짝수인 경우
			System.out.println("짝수");
			break;
		case 1: //홀수인 경우
			System.out.println("홀수");
			break;
		}

	}

}
