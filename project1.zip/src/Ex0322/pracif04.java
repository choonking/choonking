package Ex0322;

import java.util.Scanner;

public class pracif04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		// 출생년도를 입력하세요 -->>2000
		// 만 65세 이상 1958년생 
		System.out.print("출생년도를 입력하세요-->>");
		
//		int year = scan.nextInt();
//	//	char gender = year.charAt(3);
//		int a= year%10;
//		
//		if(a==1 || a==6) {
//			 System.out.print("월요일");
//		 }
//		else if(a==2 || a==7) {
//			 System.out.print("화요일");
//		 }
//		else if(a==3 || a==8) {
//			 System.out.print("수요일");
//		 }
//		else if(a==4 || a==9) {
//			 System.out.print("목요일");
//		 }
//		else if(a==5 || a==0) {
//			 System.out.print("금요일");
//		 }
//		
		//5부제를 적용할것인가?
		int year = scan.nextInt();
		if(year<=1958) {
			System.out.print("언제든 구매 가능");
			//언제든 구매 가능
			
		}
		else { //5부제 적용
			
			int a= year%10;
			
			if(a==1 || a==6) {
				 System.out.print("월요일");
			 }
			else if(a==2 || a==7) {
				 System.out.print("화요일");
			 }
			else if(a==3 || a==8) {
				 System.out.print("수요일");
			 }
			else if(a==4 || a==9) {
				 System.out.print("목요일");
			 }
			else if(a==5 || a==0) {
				 System.out.print("금요일");
			 }
		}


	}

}
