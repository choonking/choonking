package Ex0322;

import java.util.Scanner;

public class pracIf01 {

	public static void main(String[] args) {
	
		//아래의 메뉴에서 선택한 메뉴를 알려주는 프로그램을 작성하시오. 
		//1. 삽입
		//2. 수정
		//3. 삭제
		//숫자를 선택하세요. 2
		Scanner scan= new Scanner(System.in);
		
		System.out.println("1. 삽입");
		System.out.println("2. 수정");
		System.out.println("3. 삭제");
		System.out.print("숫자를 선택하세요.");
		int menu=scan.nextInt();
		if(menu ==1) {
			System.out.printf("%s을 선택하셨습니다.", "삽입");
		}
		if(menu ==2) {
			System.out.printf("%s을 선택하셨습니다.", "수정");
		}

		if(menu ==3) {
			System.out.printf("%s을 선택하셨습니다.", "삭제");
		}
	}
}