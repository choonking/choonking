package Ex0322;

import java.util.Scanner;

public class pracif02 {

	public static void main(String[] args) {
		
		//정수를 입력받아 0 이면 "zero" 양수이면 "plus" 음수이면
		//"minus" 라고 출력하는 프로그램을 작성하시오.

		Scanner scan= new Scanner(System.in);
		
		int a = scan.nextInt();
		
		if(a ==0) {
			System.out.print("zero");
		}
		if(a>0) {
			System.out.print("plus");
		}
		if(a<0) {
			System.out.print("minus");}
		
		
	}

}
