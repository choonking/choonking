package Ex0322;

import java.util.Scanner;

public class practiceX {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		
		String id  = "conan"; //회원등록시 아이디
		String pwd = "1111";  //회원등록시 비밀번호
		// 등록시 아이디와 로그인시 아이디가 일치하는지
		// 등록시 비밀번호와 로그인시 비밀번호가 일치하는지
		
		System.out.print("사용자의 아이디 입력 : ");
		String userId = scan.next();
		System.out.print("사용자의 패스워드 입력 : ");
		String userpwd = scan.next();
		
		if(id.equals(userId) && pwd.equals(userpwd)) {
		    System.out.println("로그인에 성공하셨습니다.");
		} else {
		    System.out.println("로그인에 실패하셨습니다.");
		}
	}
}
	
		 
		 
		 
	
//		{if(a==1 || a==6) {
//			 System.out.print("월요일");
//		 }
//		else if(a==2 || a==7) {
//			 System.out.print("화요일");
		
		
			
			
//		System.out.println(1 == 1);
//		System.out.println('1' == 1);//1처럼 생긴 문자
//		System.out.println(1.0==1); 
//		System.out.println(true==false);
		
		//charAt(특정한 위치 : 인덱스)->문자열중에서 
		//특정위치의 문자 한개를 골라낼때 
		//equals("") 문자열과 문자열이 서로 같은 내용인지 비교
//		System.out.println("Conan".equals("Conan"));
//		String str1 ="Aaa";
//		String str2 ="AaA";
//		System.out.println(str1.equals(str2));





