package Ex0322;

import java.util.Scanner;

public class JO1 {

	public static void main(String[] args) {
	//9031 
		
	//	정수 2개를 입력받아서 큰 수와 작은 수를 차례로 출력하는 프로그램을 작성하시오. 

		Scanner scan = new Scanner(System.in);
		
		int a = scan.nextInt();
		int b = scan.nextInt();
		
		if(a>b) { 
		System.out.printf("입력 받은 수중 큰 수는 %d이고 작은수는 %d 입니다.", a,b);
		}
		else {
			System.out.printf("입력 받은 수중 큰 수는 %d이고 작은수는 %d 입니다.", b,a);
		}
		
	
	}

}
