package Ex0322;

public class SwitchEx {

public static void main(String[] args) {
		int num = 1;
//		if(num ==1) {
//		System.out.println("1입니다");
//	}
	switch(num) {
	case 1:
		System.out.println("1입니다");
		break;
	case 2:
		System.out.println ("2입니다");
		break; //switch 탈출
	default : //없어도 괜찮음
		System.out.println("1도 아니고 2도 아닙니다.");
	}
	System.out.println("switch문 밖입니다.");

	
		}
	}



