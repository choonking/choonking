package Ex0322;

import java.util.Scanner;

public class pracSwitch {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("메뉴를 선택하세요 (1 - 3) ");
		int num = scan.nextInt();
		switch(num) { 
		case 1: 
			System.out.println("coke");
			break;
		case 2: 
			System.out.println("sprite");
			break;
		case 3: 
			System.out.println("redbull");
			break;
		default : 
			System.out.print("wrong choice");
		}
	}
}
