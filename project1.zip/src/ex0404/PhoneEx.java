package ex0404;

abstract class Phone { //abstract 키워드 때문에 추상임 
	//필드 선언
	String owner;
	
	
	//생성자 선언
	Phone(String owner) {
		this.owner = owner;
		
	}
	
	//메소드 선언
	void turnOn() {
		System.out.println("폰 전원을 켭니다.");
		
	}
	void turnOff() {
		System.out.println("폰 전원을 끕니다.");
	}
}

class SmartPhone extends Phone {
		//생성자 선언
	SmartPhone(String owner) {
		//Phone 생성자 호출
		super(owner);
		
	}
	
	void internetSearch() {
		System.out.println("인터넷 검색을 합니다.");
	}
}





public class PhoneEx {

	public static void main(String[] args) {
		//Phone phone = new Phone("장마"); <- 추상 클래스라서 객체 생성이 안됨  
		SmartPhone smartPhone = new SmartPhone("홍준표");
		
		smartPhone.turnOn();
		smartPhone.internetSearch();
		smartPhone.turnOff();
		

	}

}
