package ex0404;


interface RemoteControl {
	public void turnOn();
}

class Television implements RemoteControl {
	@Override
	public void turnOn() {
		System.out.println("TV를 켭니다.");
		
	}
}

class Airconditioner implements RemoteControl {
	@Override
	public void turnOn() {
		System.out.println("에어컨을 켭니다.");
	}
}




public class RemoteControlEx {

	public static void main(String[] args) {
		RemoteControl rc;
		rc = new Airconditioner();
//		rc = new Television();
		rc.turnOn();
		

	}

}
