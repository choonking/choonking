package ex0404;

class Person{

	private String name;
	private int age;
	public Person() {}

	public Person(String name, int age) {
		this.name=name; this.age=age; 
	}
	public String getName () {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String toString() {
		return String.format("Person[name=%s, age=%d]", name, age);
	}	


}


class Student extends Person{
	private String id;
	public Student() {}
	public Student(String name, int age, String id) {
		super(name, age);  this.id=id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String toString() {
		return String.format("Student[%s,id=%s]", super.toString(), id);
	}
}


class ForeignStudent extends Student{
	private String nationality;

	public ForeignStudent(String name, int age, String id, String nationality) {
		super(name, age, id); this.nationality=nationality;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationallity(String id) {
		this.nationality = nationality;
	}
	public String toString() {
		return String.format("ForeignStudent[%s, nationallity=%s]", super.toString(),  nationality);
	}
}




public class PersonEx {

	public static void main(String[] args) {
		
		Person p1 = new Person();
		Student s2 = new Student();
		Person p2 = s2;
		Student s = (Student)p2;
		
		System.out.println(p1 instanceof Student); //F
		System.out.println(s2 instanceof Student); //T
		System.out.println(p2 instanceof Student); //T
		System.out.println(s instanceof Student); //T
		System.out.println(s instanceof Person); //T

		
		
		
		
		

//		Person p = new Person("코난",10);
//		Student s = new Student("장미", 17, "11");
//		ForeignStudent f = new ForeignStudent(
//				"키드", 19, "22","unknown");
//		System.out.println(p.toString());
//		System.out.println(s.toString());
//		System.out.println(f.toString());

		
	}

}
