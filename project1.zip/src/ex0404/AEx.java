package ex0404;

abstract class Car{
	Car(){
		System.out.println("car 객체 생성");
	}
	abstract void run();
	void start() {
		System.out.println("시동을 건다");
	}
}

class Porche extends Car{
	void run() {
		System.out.println("포르쉐가 달린다.");

	}
}













public class AEx {

	public static void main(String[] args) {
		Car car=new Porche(); //자식이 부모의 객체로 상향 
		car.start();		  //자식이 부모를 사용
		car.run();			  //자식이 자기껄 사용 


	}

}
