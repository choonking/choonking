package ex0404;

abstract class Shape{
	abstract public double calArea(); 			
}



class Circle extends Shape{
	public double radius;

	public Circle(double radius) {
		this.radius =radius;
	}

	public double calArea() {
		return Math.PI*radius*radius;

	}

}



class Rectangle extends Shape {

	double width,height; 
	public Rectangle(double width, double height) {
		this.width=width; this.height=height;

	}
	public double calArea() {

		return width*height;

	}
}





	public class ShapeEx {

		public static void main(String[] args) {
			Shape[] sArray={new Circle(5.0), new Rectangle(3,4), new Circle(1)};
			double sum=0.0;
			for(int i=0; i<sArray.length; i++) {
				sum+=sArray[i].calArea();
			}
			System.out.println("도형들의 면적의 합은" +sum);
		}
	}

