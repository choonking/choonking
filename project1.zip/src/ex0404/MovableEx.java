package ex0404;


interface Movable {
	void moveUp();
	void moveDown();
	void moveLeft();
	void moveRight();

}



class MovablePoint implements Movable {
	private int x,y;
	private int xSpeed, ySpeed;
	public MovablePoint(int x, int y, int xSpeed, int ySpeed) {
		this.x=x; 
		this.y=y;
		this.xSpeed=xSpeed;
		this.ySpeed=ySpeed;
	}
	@Override
	public void moveDown() {
		y+=ySpeed;
	}
	@Override
	public void moveLeft() {
		x-=xSpeed;	
	}
	@Override
	public void moveUp() {
		y-=ySpeed;	
	}
	@Override
	public void moveRight() {
		x+=xSpeed;

	}
	public String toString() {
		return String.format("MovablePoint[x=%d, y=%d, xSpeed=%d, ySpeed=%d]", x,y,xSpeed,ySpeed);
	}
}
	








public class MovableEx {

	public static void main(String[] args) {

		Movable m = new MovablePoint(5,6,10,15);
		System.out.println("포인트 이동 전");
		System.out.println(m.toString());
		System.out.println("포인트 왼쪽으로 이동");
		m.moveLeft();
		System.out.println(m.toString());
		System.out.println("포인트 위로 이동");
		m.moveUp();
		System.out.println(m);


	}

}
