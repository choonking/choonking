package ex0404;

//오버라이딩의 이해  형식이 다 똑같아야됨 
abstract class Animal{// /추상 메소드가 하나라도 있으면 추상 클래스가됨
	public void breathe() {
		System.out.println("숨을 쉽니다.");
	}
	public abstract void makeSound();{ //본체(바디)없는 메소드를 추상메소드 라고 함

	}
}


/*abstract*/ class Dog extends Animal {	//자식은 부모의 추상 메소드를 반드시 구현해야한다 
	//그렇지 않으면 자식도 추상 클래스가 됨
	@Override
	public void makeSound() {
		System.out.println("멍멍");

	}

}
class Cat extends Animal {
	public void makeSound() {
		System.out.println("야옹");
	}
}

class Rat extends Animal {

	public void makeSound() {
		System.out.println("찍찍");
	}
}









public class AnimalEx {


	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.makeSound();

		Cat cat = new Cat();
		cat.makeSound();

		Rat rat = new Rat();
		rat.makeSound();

		animalSound(new Dog());
		animalSound(new Cat());
		animalSound(new Rat());
	}	
	public static void animalSound(Animal animal) {
		animal.makeSound();
	}

	//객체 생성은 안되지만 , 래퍼런스로는 사용 가능
	//		//Dog d1 = new Dog(); d1.makeSound();
	//		Animal d2 = new Dog();// d2.makeSound();
	//		//Cat c1 = new Cat(); c1.makeSound();
	//		Animal c2 = new Dog();// c2.makeSound();
	//		//Rat r1 = new Rat(); r1.makeSound();
	//		Animal r2 = new Dog();// r2.makeSound();
	//
	//		Animal[]aArray = {new Dog(), new Cat(), new Rat()};
	//		for(int i=0; i<aArray.length; i++) {
	//			aArray[i].makeSound();
}












//		d1.makeSound();
//		d1.wave();                  //객체가 자식임							//레퍼런스가 자식임
//		Animal d2 = d1;
//		d2.makeSound();
//		d2.wave(); //오버라이딩 중에는 부모의 레퍼런스로 해도 자식이 실행됨 			 
//자동 형변환 발생 (Upcasting)
//		d1.name = "초코"; 
//		d1.breed ="푸들";
//		System.out.println(d1.name); 
//		System.out.println(d1.breed);
//		System.out.println(d2.name); 
//System.out.println(d2.breed);
//다운캐스팅 (업캐스팅한 것을 되돌리는 과정) , 강제적으로 발생 (명시적으로 표기)
//		Dog d3 = (Dog)d2; //레퍼런스를 자식으로 
//		d3.makeSound(); d3.wave(); 

