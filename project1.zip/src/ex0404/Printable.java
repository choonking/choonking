package ex0404;

public interface Printable {
	int MIN = 5;
	abstract void print();

}
