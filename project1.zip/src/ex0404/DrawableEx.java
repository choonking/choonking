package ex0404;

interface Drawable{
	void draw();
}

class Rectangle1 implements Drawable{
	@Override
	public void draw() {
		System.out.println("직사각형을 그리다");
		
	}
	
}


class Circle1 implements Drawable{
	@Override
	public void draw() {
		System.out.println("원을 그리다");
		
	}
}
public class DrawableEx {

	public static void main(String[] args) {
		Drawable d = new Circle1();
		d.draw();
		// Drawable d1 = new Drawable();  <- 이건 안됨 객체 생성 불가 

	}

}
