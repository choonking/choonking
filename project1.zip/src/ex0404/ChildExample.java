package ex0404;

class Parent{ //필드선언
	public String field1;
			  //메소드 선언
	public void method1() {
		System.out.println("Parent-method1()");
	}		  //메소드 선언
	public void method2() {
		System.out.println("Parent-method2()");



	}
}

	class Child extends Parent {
		//필드 선언
		public String field2;
		//메소드 선언
		public void method3() {
			System.out.println("Child-method3()");
		}
	}







	public class ChildExample {

		public static void main(String[] args) {
			Parent parent = new Child();

			parent.field1 ="data1";
			parent.method1();
			parent.method2();

			Child child = (Child) parent;
			child.field2 = "data2";
			child.method3();


		}

	}

