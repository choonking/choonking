package ex0404;

class A{} //부모
class B extends A{} //자식
class C extends A{} //자식
class D extends B{} //손자
class E extends C{} //손자





public class PromotionEx {

	public static void main(String[] args) {
		B b = new B ();
		C c = new C ();
		D d = new D ();
		E e = new E ();
		
		A a1=b; //업캐스팅(자동형변환)
		A a2=c;
		A a3=d;
		A a4=e;
		
		B b1=d; 
		C c1=e; 
		
		
		//B b3 =e;
		//C c2 =d; 부모가 다름 
	}

}
